-- Employee Requests Table
CREATE TABLE IF NOT EXISTS `employee_requests` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `branch_id` int NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `request_type` enum('advance', 'leave', 'arrears', 'permission', 'violation_objection', 'resignation') NOT NULL,
  `request_data` text NOT NULL,
  `status` enum('تحت الإجراء', 'مقبول', 'مرفوض') NOT NULL DEFAULT 'تحت الإجراء',
  `admin_response` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `responded_at` timestamp NULL,
  INDEX `idx_employee_requests_branch` (`branch_id`),
  INDEX `idx_employee_requests_status` (`status`),
  INDEX `idx_employee_requests_type` (`request_type`),
  INDEX `idx_employee_requests_created` (`created_at`),
  FOREIGN KEY (`branch_id`) REFERENCES `branches`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Product Orders Table
CREATE TABLE IF NOT EXISTS `product_orders` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `branch_id` int NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `products` text NOT NULL,
  `grand_total` decimal(15, 2) NOT NULL,
  `status` enum('pending', 'approved', 'rejected', 'delivered') NOT NULL DEFAULT 'pending',
  `admin_response` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `approved_at` timestamp NULL,
  `rejected_at` timestamp NULL,
  `delivered_at` timestamp NULL,
  INDEX `idx_product_orders_branch` (`branch_id`),
  INDEX `idx_product_orders_status` (`status`),
  INDEX `idx_product_orders_created` (`created_at`),
  FOREIGN KEY (`branch_id`) REFERENCES `branches`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Request Audit Log Table
CREATE TABLE IF NOT EXISTS `request_audit_log` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `request_type` enum('employee_request', 'product_order') NOT NULL,
  `request_id` int NOT NULL,
  `action` varchar(100) NOT NULL,
  `old_status` varchar(50),
  `new_status` varchar(50),
  `performed_by` varchar(255) NOT NULL,
  `details` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_request_audit_type_id` (`request_type`, `request_id`),
  INDEX `idx_request_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Request Notifications Table
CREATE TABLE IF NOT EXISTS `request_notifications` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `request_type` enum('employee_request', 'product_order') NOT NULL,
  `request_id` int NOT NULL,
  `recipient_user_id` int NOT NULL,
  `message` text NOT NULL,
  `is_read` boolean NOT NULL DEFAULT false,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_request_notif_recipient` (`recipient_user_id`, `is_read`),
  INDEX `idx_request_notif_type_id` (`request_type`, `request_id`),
  FOREIGN KEY (`recipient_user_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
