import { readFileSync } from 'fs';
import mysql from 'mysql2/promise';
import { config } from 'dotenv';

config();

async function applyMigration() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  
  console.log('📦 Connected to database');
  
  const sql = readFileSync('./manual_migration.sql', 'utf8');
  const statements = sql.split(';').filter(s => s.trim().length > 0);
  
  console.log(`📝 Executing ${statements.length} SQL statements...`);
  
  for (let i = 0; i < statements.length; i++) {
    const statement = statements[i].trim();
    if (statement) {
      try {
        await connection.query(statement);
        console.log(`  ✓ Statement ${i + 1}/${statements.length} executed`);
      } catch (error) {
        console.error(`  ✗ Statement ${i + 1} failed:`, error.message);
      }
    }
  }
  
  console.log('\n✅ Migration completed!');
  await connection.end();
}

applyMigration().catch(console.error);
