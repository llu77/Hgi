import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { CheckCircle2, XCircle, Eye, Calendar, DollarSign, Users } from 'lucide-react';

export default function AdminBonuses() {
  const [selectedBonus, setSelectedBonus] = useState<any>(null);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');

  // Fetch pending requests
  const { data: pendingRequests, isLoading, refetch } = trpc.bonuses.pending.useQuery();

  // Approve mutation
  const approveMutation = trpc.bonuses.approve.useMutation({
    onSuccess: () => {
      toast.success('تمت الموافقة على البونص بنجاح');
      setShowApproveDialog(false);
      setShowDetailsDialog(false);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || 'فشلت عملية الموافقة');
    },
  });

  // Reject mutation
  const rejectMutation = trpc.bonuses.reject.useMutation({
    onSuccess: () => {
      toast.success('تم رفض البونص');
      setShowRejectDialog(false);
      setShowDetailsDialog(false);
      setRejectionReason('');
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || 'فشلت عملية الرفض');
    },
  });

  // Fetch bonus details for selected request
  const { data: bonusDetails, isLoading: detailsLoading } = trpc.bonuses.getWeek.useQuery(
    {
      year: selectedBonus?.year || 0,
      month: selectedBonus?.month || 0,
      weekNumber: selectedBonus?.weekNumber || 0,
    },
    {
      enabled: !!selectedBonus,
    }
  );

  const handleViewDetails = (bonus: any) => {
    setSelectedBonus(bonus);
    setShowDetailsDialog(true);
  };

  const handleApprove = () => {
    if (selectedBonus) {
      approveMutation.mutate({ weeklyBonusId: selectedBonus.id });
    }
  };

  const handleReject = () => {
    if (selectedBonus && rejectionReason.trim()) {
      rejectMutation.mutate({
        weeklyBonusId: selectedBonus.id,
        reason: rejectionReason.trim(),
      });
    } else {
      toast.error('يرجى إدخال سبب الرفض');
    }
  };

  const getTierBadge = (tier: string) => {
    const tierLabels: Record<string, string> = {
      tier_5: 'المستوى 5',
      tier_4: 'المستوى 4',
      tier_3: 'المستوى 3',
      tier_2: 'المستوى 2',
      tier_1: 'المستوى 1',
      none: 'غير مؤهل',
    };

    const tierColors: Record<string, string> = {
      tier_5: 'bg-purple-500',
      tier_4: 'bg-blue-500',
      tier_3: 'bg-green-500',
      tier_2: 'bg-yellow-500',
      tier_1: 'bg-orange-500',
      none: 'bg-gray-400',
    };

    return (
      <Badge className={`${tierColors[tier] || 'bg-gray-400'} text-white`}>
        {tierLabels[tier] || tier}
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <div className="container mx-auto py-8 space-y-6">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold mb-2">طلبات البونص المعلقة</h1>
        <p className="text-muted-foreground">
          مراجعة والموافقة على طلبات صرف البونصات الأسبوعية
        </p>
      </div>

      {/* Pending Requests */}
      <Card>
        <CardHeader>
          <CardTitle>الطلبات المعلقة ({pendingRequests?.length || 0})</CardTitle>
          <CardDescription>طلبات البونص في انتظار الموافقة</CardDescription>
        </CardHeader>
        <CardContent>
          {pendingRequests && pendingRequests.length > 0 ? (
            <div className="border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>الفرع</TableHead>
                    <TableHead>الأسبوع</TableHead>
                    <TableHead>الفترة</TableHead>
                    <TableHead>المشرف</TableHead>
                    <TableHead className="text-right">الإجمالي</TableHead>
                    <TableHead>المؤهلون</TableHead>
                    <TableHead>تاريخ الطلب</TableHead>
                    <TableHead className="text-center">الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingRequests.map((request: any) => (
                    <TableRow key={request.id}>
                      <TableCell className="font-medium">{request.branchName}</TableCell>
                      <TableCell>الأسبوع {request.weekNumber}</TableCell>
                      <TableCell>
                        {new Date(request.weekStart).toLocaleDateString('ar-SA', {
                          month: 'short',
                          day: 'numeric',
                        })}{' '}
                        -{' '}
                        {new Date(request.weekEnd).toLocaleDateString('ar-SA', {
                          month: 'short',
                          day: 'numeric',
                        })}
                      </TableCell>
                      <TableCell>{request.supervisorName || '-'}</TableCell>
                      <TableCell className="text-right font-bold text-green-600">
                        {Number(request.totalAmount).toFixed(2)} ر.س
                      </TableCell>
                      <TableCell>{request.eligibleCount}</TableCell>
                      <TableCell>
                        {request.requestedAt
                          ? new Date(request.requestedAt).toLocaleDateString('ar-SA')
                          : '-'}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleViewDetails(request)}
                          >
                            <Eye className="h-4 w-4 ml-2" />
                            عرض التفاصيل
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center text-muted-foreground py-12">
              <CheckCircle2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>لا توجد طلبات معلقة حالياً</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Bonus Details Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              تفاصيل البونص - {selectedBonus?.branchName} - الأسبوع {selectedBonus?.weekNumber}
            </DialogTitle>
            <DialogDescription>
              {selectedBonus &&
                `${new Date(selectedBonus.weekStart).toLocaleDateString('ar-SA')} - ${new Date(
                  selectedBonus.weekEnd
                ).toLocaleDateString('ar-SA')}`}
            </DialogDescription>
          </DialogHeader>

          {detailsLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-64 w-full" />
            </div>
          ) : bonusDetails ? (
            <div className="space-y-6">
              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-green-100 dark:bg-green-900 rounded-lg">
                        <DollarSign className="h-6 w-6 text-green-600 dark:text-green-400" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">إجمالي البونص</p>
                        <p className="text-2xl font-bold">
                          {Number(bonusDetails.totalAmount).toFixed(2)} ر.س
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                        <Users className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">الموظفون المؤهلون</p>
                        <p className="text-2xl font-bold">{bonusDetails.eligibleCount}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-purple-100 dark:bg-purple-900 rounded-lg">
                        <Calendar className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">إجمالي الموظفين</p>
                        <p className="text-2xl font-bold">{bonusDetails.employees?.length || 0}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Employee Details Table */}
              <div>
                <h3 className="text-lg font-semibold mb-4">تفاصيل بونص الموظفين</h3>
                <div className="border rounded-lg">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>الموظف</TableHead>
                        <TableHead>الكود</TableHead>
                        <TableHead className="text-right">الإيراد الأسبوعي</TableHead>
                        <TableHead>المستوى</TableHead>
                        <TableHead className="text-right">البونص</TableHead>
                        <TableHead>الحالة</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {bonusDetails.employees && bonusDetails.employees.length > 0 ? (
                        bonusDetails.employees.map((emp: any) => (
                          <TableRow key={emp.id}>
                            <TableCell className="font-medium">{emp.employeeName}</TableCell>
                            <TableCell>{emp.employeeCode}</TableCell>
                            <TableCell className="text-right">
                              {Number(emp.weeklyRevenue).toFixed(2)} ر.س
                            </TableCell>
                            <TableCell>{getTierBadge(emp.bonusTier)}</TableCell>
                            <TableCell className="text-right font-bold">
                              {Number(emp.bonusAmount).toFixed(2)} ر.س
                            </TableCell>
                            <TableCell>
                              {emp.isEligible ? (
                                <Badge variant="default" className="bg-green-500">
                                  مؤهل
                                </Badge>
                              ) : (
                                <Badge variant="secondary">غير مؤهل</Badge>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                            لا توجد بيانات للموظفين
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center text-muted-foreground py-8">
              فشل تحميل التفاصيل
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button
              variant="destructive"
              onClick={() => setShowRejectDialog(true)}
              disabled={rejectMutation.isPending}
            >
              <XCircle className="h-4 w-4 ml-2" />
              رفض
            </Button>
            <Button
              onClick={() => setShowApproveDialog(true)}
              disabled={approveMutation.isPending}
            >
              <CheckCircle2 className="h-4 w-4 ml-2" />
              موافقة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Approve Confirmation Dialog */}
      <AlertDialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد الموافقة على البونص</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من الموافقة على صرف هذا البونص؟ لن يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={handleApprove} disabled={approveMutation.isPending}>
              {approveMutation.isPending ? 'جاري الموافقة...' : 'تأكيد الموافقة'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Reject Dialog */}
      <AlertDialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>رفض طلب البونص</AlertDialogTitle>
            <AlertDialogDescription>
              يرجى إدخال سبب رفض الطلب. سيتم إعادة الحالة إلى "قيد الانتظار" ليتمكن المشرف من
              تصحيح البيانات وإعادة الطلب.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="py-4">
            <Label htmlFor="rejection-reason">سبب الرفض</Label>
            <Textarea
              id="rejection-reason"
              placeholder="مثال: بيانات غير صحيحة، يرجى المراجعة والتصحيح"
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              className="mt-2"
              rows={4}
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setRejectionReason('')}>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleReject}
              disabled={rejectMutation.isPending || !rejectionReason.trim()}
              className="bg-destructive hover:bg-destructive/90"
            >
              {rejectMutation.isPending ? 'جاري الرفض...' : 'تأكيد الرفض'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
