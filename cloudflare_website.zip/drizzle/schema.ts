import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, index, unique } from "drizzle-orm/mysql-core";

/**
 * Financial Management System Database Schema
 * Designed for multi-branch revenue and expense tracking with role-based access control
 */

// ============================================================================
// CORE SYSTEM TABLES
// ============================================================================

/**
 * Branches - Multi-location support
 */
export const branches = mysqlTable("branches", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 50 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  nameAr: varchar("name_ar", { length: 255 }).notNull(),
  address: text("address"),
  phone: varchar("phone", { length: 50 }),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  codeIdx: index("idx_branches_code").on(table.code),
}));

export type Branch = typeof branches.$inferSelect;
export type InsertBranch = typeof branches.$inferInsert;

/**
 * Users - Authentication and authorization
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  passwordHash: varchar("password_hash", { length: 255 }),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["admin", "manager", "employee"]).default("employee").notNull(),
  branchId: int("branch_id").references(() => branches.id),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("last_signed_in").defaultNow().notNull(),
}, (table) => ({
  openIdIdx: index("idx_users_openid").on(table.openId),
  usernameIdx: index("idx_users_username").on(table.username),
  branchIdx: index("idx_users_branch").on(table.branchId),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Employees - Staff members linked to branches
 */
export const employees = mysqlTable("employees", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 50 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  branchId: int("branch_id").references(() => branches.id).notNull(),
  phone: varchar("phone", { length: 50 }),
  position: varchar("position", { length: 100 }),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  branchIdx: index("idx_employees_branch").on(table.branchId),
  codeIdx: index("idx_employees_code").on(table.code),
  uniqueCodeBranch: unique("unique_employee_code_branch").on(table.code, table.branchId),
}));

export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = typeof employees.$inferInsert;

// ============================================================================
// REVENUE MANAGEMENT TABLES
// ============================================================================

/**
 * Monthly Records - Revenue tracking periods (1st to end of month)
 */
export const monthlyRecords = mysqlTable("monthly_records", {
  id: int("id").autoincrement().primaryKey(),
  branchId: int("branch_id").references(() => branches.id).notNull(),
  year: int("year").notNull(),
  month: int("month").notNull(), // 1-12
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  status: mysqlEnum("status", ["active", "closed"]).default("active").notNull(),
  totalCash: decimal("total_cash", { precision: 15, scale: 2 }).default("0.00"),
  totalNetwork: decimal("total_network", { precision: 15, scale: 2 }).default("0.00"),
  totalRevenue: decimal("total_revenue", { precision: 15, scale: 2 }).default("0.00"),
  closedBy: int("closed_by").references(() => users.id),
  closedAt: timestamp("closed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  branchYearMonthIdx: index("idx_monthly_records_branch_year_month").on(table.branchId, table.year, table.month),
  uniqueBranchYearMonth: unique("unique_branch_year_month").on(table.branchId, table.year, table.month),
}));

export type MonthlyRecord = typeof monthlyRecords.$inferSelect;
export type InsertMonthlyRecord = typeof monthlyRecords.$inferInsert;

/**
 * Daily Revenues - Daily revenue entries with accounting validation
 */
export const dailyRevenues = mysqlTable("daily_revenues", {
  id: int("id").autoincrement().primaryKey(),
  monthlyRecordId: int("monthly_record_id").references(() => monthlyRecords.id).notNull(),
  branchId: int("branch_id").references(() => branches.id).notNull(),
  date: timestamp("date").notNull(),
  cash: decimal("cash", { precision: 15, scale: 2 }).notNull(),
  network: decimal("network", { precision: 15, scale: 2 }).notNull(),
  balance: decimal("balance", { precision: 15, scale: 2 }).notNull(),
  total: decimal("total", { precision: 15, scale: 2 }).notNull(),
  isMatched: boolean("is_matched").notNull(),
  unmatchReason: text("unmatch_reason"),
  createdBy: int("created_by").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  monthlyRecordIdx: index("idx_daily_revenues_monthly_record").on(table.monthlyRecordId),
  branchDateIdx: index("idx_daily_revenues_branch_date").on(table.branchId, table.date),
  dateIdx: index("idx_daily_revenues_date").on(table.date),
}));

export type DailyRevenue = typeof dailyRevenues.$inferSelect;
export type InsertDailyRevenue = typeof dailyRevenues.$inferInsert;

/**
 * Employee Revenues - Individual employee revenue contributions
 */
export const employeeRevenues = mysqlTable("employee_revenues", {
  id: int("id").autoincrement().primaryKey(),
  dailyRevenueId: int("daily_revenue_id").references(() => dailyRevenues.id).notNull(),
  employeeId: int("employee_id").references(() => employees.id).notNull(),
  cash: decimal("cash", { precision: 15, scale: 2 }).default("0.00").notNull(),
  network: decimal("network", { precision: 15, scale: 2 }).default("0.00").notNull(),
  total: decimal("total", { precision: 15, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  dailyRevenueIdx: index("idx_employee_revenues_daily_revenue").on(table.dailyRevenueId),
  employeeIdx: index("idx_employee_revenues_employee").on(table.employeeId),
}));

export type EmployeeRevenue = typeof employeeRevenues.$inferSelect;
export type InsertEmployeeRevenue = typeof employeeRevenues.$inferInsert;

// ============================================================================
// EXPENSE MANAGEMENT TABLES
// ============================================================================

/**
 * Expense Categories - 15 predefined expense types
 */
export const expenseCategories = mysqlTable("expense_categories", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 50 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  nameAr: varchar("name_ar", { length: 255 }).notNull(),
  icon: varchar("icon", { length: 50 }),
  color: varchar("color", { length: 50 }),
  sortOrder: int("sort_order").default(0),
  requiresEmployee: boolean("requires_employee").default(false).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  codeIdx: index("idx_expense_categories_code").on(table.code),
}));

export type ExpenseCategory = typeof expenseCategories.$inferSelect;
export type InsertExpenseCategory = typeof expenseCategories.$inferInsert;

/**
 * Expenses - Expense tracking with soft delete
 */
export const expenses = mysqlTable("expenses", {
  id: int("id").autoincrement().primaryKey(),
  branchId: int("branch_id").references(() => branches.id).notNull(),
  categoryId: int("category_id").references(() => expenseCategories.id).notNull(),
  date: timestamp("date").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  paymentType: mysqlEnum("payment_type", ["cash", "network"]).notNull(),
  description: text("description"),
  employeeId: int("employee_id").references(() => employees.id),
  receiptNumber: varchar("receipt_number", { length: 100 }),
  createdBy: int("created_by").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
  deletedAt: timestamp("deleted_at"),
}, (table) => ({
  branchDateIdx: index("idx_expenses_branch_date").on(table.branchId, table.date),
  categoryIdx: index("idx_expenses_category").on(table.categoryId),
  dateIdx: index("idx_expenses_date").on(table.date),
  deletedIdx: index("idx_expenses_deleted").on(table.deletedAt),
}));

export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = typeof expenses.$inferInsert;

// ============================================================================
// SYSTEM LOGS (keeping from original schema)
// ============================================================================

/**
 * System logs for monitoring and audit trail
 */
export const systemLogs = mysqlTable("system_logs", {
  id: int("id").autoincrement().primaryKey(),
  level: mysqlEnum("level", ["info", "warning", "error", "critical"]).notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  message: text("message").notNull(),
  metadata: text("metadata"),
  userId: int("user_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  levelIdx: index("idx_system_logs_level").on(table.level),
  categoryIdx: index("idx_system_logs_category").on(table.category),
  createdAtIdx: index("idx_system_logs_created_at").on(table.createdAt),
}));

export type SystemLog = typeof systemLogs.$inferSelect;
export type InsertSystemLog = typeof systemLogs.$inferInsert;

// ============================================================================
// WEEKLY BONUS SYSTEM TABLES
// ============================================================================

/**
 * Weekly Bonuses - Track weekly bonus calculations per branch
 * Weeks are calculated as: 1(1-7), 2(8-15), 3(16-22), 4(23-29), 5(30-31)
 */
export const weeklyBonuses = mysqlTable("weekly_bonuses", {
  id: int("id").autoincrement().primaryKey(),
  branchId: int("branch_id").references(() => branches.id).notNull(),
  weekNumber: int("week_number").notNull(), // 1-5
  weekStart: timestamp("week_start").notNull(),
  weekEnd: timestamp("week_end").notNull(),
  month: int("month").notNull(), // 1-12
  year: int("year").notNull(),
  status: mysqlEnum("status", ["pending", "requested", "approved", "rejected"]).default("pending").notNull(),
  requestedAt: timestamp("requested_at"),
  requestedBy: int("requested_by").references(() => users.id),
  approvedAt: timestamp("approved_at"),
  approvedBy: int("approved_by").references(() => users.id),
  rejectedAt: timestamp("rejected_at"),
  rejectedBy: int("rejected_by").references(() => users.id),
  rejectionReason: text("rejection_reason"),
  totalAmount: decimal("total_amount", { precision: 15, scale: 2 }).default("0.00").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  statusIdx: index("idx_weekly_bonuses_status").on(table.status),
  branchPeriodIdx: index("idx_weekly_bonuses_branch_period").on(table.branchId, table.year, table.month),
  uniqueBranchWeek: unique("unique_branch_week").on(table.branchId, table.year, table.month, table.weekNumber),
}));

export type WeeklyBonus = typeof weeklyBonuses.$inferSelect;
export type InsertWeeklyBonus = typeof weeklyBonuses.$inferInsert;

/**
 * Bonus Details - Individual employee bonus breakdown
 * Bonus tiers:
 * - Tier 5: ≥2400 SAR → 180 SAR
 * - Tier 4: 2100-2399 SAR → 135 SAR
 * - Tier 3: 1800-2099 SAR → 95 SAR
 * - Tier 2: 1500-1799 SAR → 60 SAR
 * - Tier 1: 1200-1499 SAR → 35 SAR
 * - None: <1200 SAR → 0 SAR
 */
export const bonusDetails = mysqlTable("bonus_details", {
  id: int("id").autoincrement().primaryKey(),
  weeklyBonusId: int("weekly_bonus_id").references(() => weeklyBonuses.id).notNull(),
  employeeId: int("employee_id").references(() => employees.id).notNull(),
  weeklyRevenue: decimal("weekly_revenue", { precision: 15, scale: 2 }).default("0.00").notNull(),
  bonusAmount: decimal("bonus_amount", { precision: 15, scale: 2 }).default("0.00").notNull(),
  bonusTier: mysqlEnum("bonus_tier", ["tier_1", "tier_2", "tier_3", "tier_4", "tier_5", "none"]).notNull(),
  isEligible: boolean("is_eligible").default(false).notNull(),
  evaluationScore: decimal("evaluation_score", { precision: 3, scale: 2 }), // Future use: 0.00-5.00
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  weeklyBonusIdx: index("idx_bonus_details_weekly_bonus").on(table.weeklyBonusId),
  employeeIdx: index("idx_bonus_details_employee").on(table.employeeId),
  uniqueWeeklyEmployee: unique("unique_weekly_employee").on(table.weeklyBonusId, table.employeeId),
}));

export type BonusDetail = typeof bonusDetails.$inferSelect;
export type InsertBonusDetail = typeof bonusDetails.$inferInsert;

/**
 * Bonus Audit Log - Track all status changes and actions on bonus records
 */
export const bonusAuditLog = mysqlTable("bonus_audit_log", {
  id: int("id").autoincrement().primaryKey(),
  weeklyBonusId: int("weekly_bonus_id").references(() => weeklyBonuses.id).notNull(),
  action: varchar("action", { length: 100 }).notNull(),
  oldStatus: varchar("old_status", { length: 50 }),
  newStatus: varchar("new_status", { length: 50 }),
  performedBy: int("performed_by").references(() => users.id).notNull(),
  performedAt: timestamp("performed_at").defaultNow().notNull(),
  details: text("details"),
  metadata: text("metadata"),
}, (table) => ({
  weeklyBonusIdx: index("idx_audit_weekly_bonus").on(table.weeklyBonusId),
  performedAtIdx: index("idx_audit_performed_at").on(table.performedAt),
}));

export type BonusAuditLog = typeof bonusAuditLog.$inferSelect;
export type InsertBonusAuditLog = typeof bonusAuditLog.$inferInsert;


// ============================================================================
// EMPLOYEE REQUESTS & PRODUCT ORDERS SYSTEM
// ============================================================================

/**
 * Employee Requests - 6 types of employee requests
 * Types: advance, leave, arrears, permission, violation_objection, resignation
 */
export const employeeRequests = mysqlTable("employee_requests", {
  id: int("id").autoincrement().primaryKey(),
  branchId: int("branch_id").references(() => branches.id).notNull(),
  branchName: varchar("branch_name", { length: 255 }).notNull(),
  employeeName: varchar("employee_name", { length: 255 }).notNull(),
  requestType: mysqlEnum("request_type", [
    "advance",
    "leave",
    "arrears",
    "permission",
    "violation_objection",
    "resignation"
  ]).notNull(),
  requestData: text("request_data").notNull(), // JSON data specific to request type
  status: mysqlEnum("status", ["تحت الإجراء", "مقبول", "مرفوض"]).default("تحت الإجراء").notNull(),
  adminResponse: text("admin_response"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  respondedAt: timestamp("responded_at"),
}, (table) => ({
  branchIdx: index("idx_employee_requests_branch").on(table.branchId),
  statusIdx: index("idx_employee_requests_status").on(table.status),
  typeIdx: index("idx_employee_requests_type").on(table.requestType),
  createdAtIdx: index("idx_employee_requests_created").on(table.createdAt),
}));

export type EmployeeRequest = typeof employeeRequests.$inferSelect;
export type InsertEmployeeRequest = typeof employeeRequests.$inferInsert;

/**
 * Product Orders - Employee product order requests
 */
export const productOrders = mysqlTable("product_orders", {
  id: int("id").autoincrement().primaryKey(),
  branchId: int("branch_id").references(() => branches.id).notNull(),
  branchName: varchar("branch_name", { length: 255 }).notNull(),
  employeeName: varchar("employee_name", { length: 255 }).notNull(),
  products: text("products").notNull(), // JSON array of products
  grandTotal: decimal("grand_total", { precision: 15, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "delivered"]).default("pending").notNull(),
  adminResponse: text("admin_response"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  approvedAt: timestamp("approved_at"),
  rejectedAt: timestamp("rejected_at"),
  deliveredAt: timestamp("delivered_at"),
}, (table) => ({
  branchIdx: index("idx_product_orders_branch").on(table.branchId),
  statusIdx: index("idx_product_orders_status").on(table.status),
  createdAtIdx: index("idx_product_orders_created").on(table.createdAt),
}));

export type ProductOrder = typeof productOrders.$inferSelect;
export type InsertProductOrder = typeof productOrders.$inferInsert;

/**
 * Request Audit Log - Track all actions on employee requests and product orders
 */
export const requestAuditLog = mysqlTable("request_audit_log", {
  id: int("id").autoincrement().primaryKey(),
  requestType: mysqlEnum("request_type", ["employee_request", "product_order"]).notNull(),
  requestId: int("request_id").notNull(),
  action: varchar("action", { length: 100 }).notNull(),
  oldStatus: varchar("old_status", { length: 50 }),
  newStatus: varchar("new_status", { length: 50 }),
  performedBy: varchar("performed_by", { length: 255 }).notNull(),
  details: text("details"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  requestIdx: index("idx_request_audit_request").on(table.requestId),
  typeIdx: index("idx_request_audit_type").on(table.requestType),
  createdAtIdx: index("idx_request_audit_created").on(table.createdAt),
}));

export type RequestAuditLog = typeof requestAuditLog.$inferSelect;
export type InsertRequestAuditLog = typeof requestAuditLog.$inferInsert;

/**
 * Request Notifications - Notifications for employee requests and product orders
 */
export const requestNotifications = mysqlTable("request_notifications", {
  id: int("id").autoincrement().primaryKey(),
  requestType: mysqlEnum("request_type", ["employee_request", "product_order"]).notNull(),
  requestId: int("request_id").notNull(),
  notificationType: mysqlEnum("notification_type", ["new_request", "status_changed"]).notNull(),
  recipientType: mysqlEnum("recipient_type", ["admin", "employee"]).notNull(),
  recipientId: varchar("recipient_id", { length: 255 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  readAt: timestamp("read_at"),
  sentViaEmail: boolean("sent_via_email").default(false).notNull(),
  emailSentAt: timestamp("email_sent_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  recipientIdx: index("idx_request_notifications_recipient").on(table.recipientId),
  isReadIdx: index("idx_request_notifications_read").on(table.isRead),
  createdAtIdx: index("idx_request_notifications_created").on(table.createdAt),
}));

export type RequestNotification = typeof requestNotifications.$inferSelect;
export type InsertRequestNotification = typeof requestNotifications.$inferInsert;
