-- Manual migration for financial management system
-- Drop old tables first
DROP TABLE IF EXISTS `kv_metadata`;
DROP TABLE IF EXISTS `files`;
DROP TABLE IF EXISTS `demo_records`;

-- Create new tables
CREATE TABLE IF NOT EXISTS `branches` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `code` varchar(50) NOT NULL UNIQUE,
  `name` varchar(255) NOT NULL,
  `name_ar` varchar(255) NOT NULL,
  `address` text,
  `phone` varchar(50),
  `is_active` boolean NOT NULL DEFAULT true,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_branches_code` (`code`)
);

CREATE TABLE IF NOT EXISTS `users` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `openId` varchar(64) NOT NULL UNIQUE,
  `username` varchar(100) NOT NULL UNIQUE,
  `name` text,
  `email` varchar(320),
  `loginMethod` varchar(64),
  `role` enum('admin', 'manager', 'employee') NOT NULL DEFAULT 'employee',
  `branch_id` int,
  `is_active` boolean NOT NULL DEFAULT true,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_signed_in` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`branch_id`) REFERENCES `branches`(`id`),
  INDEX `idx_users_openid` (`openId`),
  INDEX `idx_users_username` (`username`),
  INDEX `idx_users_branch` (`branch_id`)
);

CREATE TABLE IF NOT EXISTS `employees` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `branch_id` int NOT NULL,
  `phone` varchar(50),
  `position` varchar(100),
  `is_active` boolean NOT NULL DEFAULT true,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`branch_id`) REFERENCES `branches`(`id`),
  INDEX `idx_employees_branch` (`branch_id`),
  INDEX `idx_employees_code` (`code`),
  UNIQUE KEY `unique_employee_code_branch` (`code`, `branch_id`)
);

CREATE TABLE IF NOT EXISTS `monthly_records` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `branch_id` int NOT NULL,
  `year` int NOT NULL,
  `month` int NOT NULL,
  `start_date` timestamp NOT NULL,
  `end_date` timestamp NOT NULL,
  `status` enum('active', 'closed') NOT NULL DEFAULT 'active',
  `total_cash` decimal(15, 2) DEFAULT '0.00',
  `total_network` decimal(15, 2) DEFAULT '0.00',
  `total_revenue` decimal(15, 2) DEFAULT '0.00',
  `closed_by` int,
  `closed_at` timestamp NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`branch_id`) REFERENCES `branches`(`id`),
  FOREIGN KEY (`closed_by`) REFERENCES `users`(`id`),
  INDEX `idx_monthly_records_branch_year_month` (`branch_id`, `year`, `month`),
  UNIQUE KEY `unique_branch_year_month` (`branch_id`, `year`, `month`)
);

CREATE TABLE IF NOT EXISTS `daily_revenues` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `monthly_record_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `date` timestamp NOT NULL,
  `cash` decimal(15, 2) NOT NULL,
  `network` decimal(15, 2) NOT NULL,
  `balance` decimal(15, 2) NOT NULL,
  `total` decimal(15, 2) NOT NULL,
  `is_matched` boolean NOT NULL,
  `unmatch_reason` text,
  `created_by` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`monthly_record_id`) REFERENCES `monthly_records`(`id`),
  FOREIGN KEY (`branch_id`) REFERENCES `branches`(`id`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`),
  INDEX `idx_daily_revenues_monthly_record` (`monthly_record_id`),
  INDEX `idx_daily_revenues_branch_date` (`branch_id`, `date`),
  INDEX `idx_daily_revenues_date` (`date`)
);

CREATE TABLE IF NOT EXISTS `employee_revenues` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `daily_revenue_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `cash` decimal(15, 2) NOT NULL DEFAULT '0.00',
  `network` decimal(15, 2) NOT NULL DEFAULT '0.00',
  `total` decimal(15, 2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`daily_revenue_id`) REFERENCES `daily_revenues`(`id`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`),
  INDEX `idx_employee_revenues_daily_revenue` (`daily_revenue_id`),
  INDEX `idx_employee_revenues_employee` (`employee_id`)
);

CREATE TABLE IF NOT EXISTS `expense_categories` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `code` varchar(50) NOT NULL UNIQUE,
  `name` varchar(255) NOT NULL,
  `name_ar` varchar(255) NOT NULL,
  `icon` varchar(50),
  `color` varchar(50),
  `sort_order` int DEFAULT 0,
  `requires_employee` boolean NOT NULL DEFAULT false,
  `is_active` boolean NOT NULL DEFAULT true,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_expense_categories_code` (`code`)
);

CREATE TABLE IF NOT EXISTS `expenses` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `branch_id` int NOT NULL,
  `category_id` int NOT NULL,
  `date` timestamp NOT NULL,
  `amount` decimal(15, 2) NOT NULL,
  `payment_type` enum('cash', 'network') NOT NULL,
  `description` text,
  `employee_id` int,
  `receipt_number` varchar(100),
  `created_by` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL,
  FOREIGN KEY (`branch_id`) REFERENCES `branches`(`id`),
  FOREIGN KEY (`category_id`) REFERENCES `expense_categories`(`id`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`),
  INDEX `idx_expenses_branch_date` (`branch_id`, `date`),
  INDEX `idx_expenses_category` (`category_id`),
  INDEX `idx_expenses_date` (`date`),
  INDEX `idx_expenses_deleted` (`deleted_at`)
);

CREATE TABLE IF NOT EXISTS `system_logs` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `level` enum('info', 'warning', 'error', 'critical') NOT NULL,
  `category` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `metadata` text,
  `user_id` int,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_system_logs_level` (`level`),
  INDEX `idx_system_logs_category` (`category`),
  INDEX `idx_system_logs_created_at` (`created_at`)
);
