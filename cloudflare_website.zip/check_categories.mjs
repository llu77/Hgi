import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import { expenseCategories } from './drizzle/schema.ts';

const connection = await mysql.createConnection(process.env.DATABASE_URL);
const db = drizzle(connection);

const categories = await db.select().from(expenseCategories);
console.log(`Found ${categories.length} expense categories:`);
categories.forEach(cat => console.log(`- ${cat.nameAr} (${cat.code})`));

await connection.end();
