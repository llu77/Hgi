/**
 * Weekly Bonus Calculator
 * Implements the 5-tier bonus system based on weekly revenue performance
 */

// ═══════════════════════════════════════
// Bonus Tier Definitions
// ═══════════════════════════════════════
export const BONUS_TIERS = [
  { min: 2400, max: Infinity, amount: 180, tier: 'tier_5' as const },
  { min: 2100, max: 2399, amount: 135, tier: 'tier_4' as const },
  { min: 1800, max: 2099, amount: 95, tier: 'tier_3' as const },
  { min: 1500, max: 1799, amount: 60, tier: 'tier_2' as const },
  { min: 1200, max: 1499, amount: 35, tier: 'tier_1' as const },
  { min: 0, max: 1199, amount: 0, tier: 'none' as const },
];

export type BonusTier = 'tier_1' | 'tier_2' | 'tier_3' | 'tier_4' | 'tier_5' | 'none';

// ═══════════════════════════════════════
// Week Information Interface
// ═══════════════════════════════════════
export interface WeekInfo {
  weekNumber: number; // 1-5
  weekStart: string; // YYYY-MM-DD
  weekEnd: string; // YYYY-MM-DD
  month: number; // 1-12
  year: number;
}

// ═══════════════════════════════════════
// Bonus Calculation Result
// ═══════════════════════════════════════
export interface BonusResult {
  amount: number;
  tier: BonusTier;
  isEligible: boolean;
}

// ═══════════════════════════════════════
// Get Week Information from Date
// ═══════════════════════════════════════
/**
 * Determines which week of the month a given date falls into
 * Week boundaries:
 * - Week 1: Days 1-7
 * - Week 2: Days 8-15
 * - Week 3: Days 16-22
 * - Week 4: Days 23-29
 * - Week 5: Days 30-31 (remaining days)
 */
export function getWeekInfo(date: Date): WeekInfo {
  const day = date.getDate();
  const month = date.getMonth() + 1; // 0-indexed to 1-indexed
  const year = date.getFullYear();
  
  // Get last day of the month
  const lastDay = new Date(year, date.getMonth() + 1, 0).getDate();

  // Define week boundaries
  const weeks = [
    { num: 1, start: 1, end: 7 },
    { num: 2, start: 8, end: 15 },
    { num: 3, start: 16, end: 22 },
    { num: 4, start: 23, end: 29 },
    { num: 5, start: 30, end: lastDay }, // Remaining days (30-31)
  ];

  // Find which week the day falls into
  const week = weeks.find((w) => day >= w.start && day <= w.end);
  
  if (!week) {
    throw new Error(`Invalid day: ${day} for month with ${lastDay} days`);
  }

  // Calculate week start and end dates
  const weekStart = new Date(year, date.getMonth(), week.start);
  const weekEnd = new Date(year, date.getMonth(), Math.min(week.end, lastDay));

  // Format as YYYY-MM-DD
  const formatDate = (d: Date) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  };

  return {
    weekNumber: week.num,
    weekStart: formatDate(weekStart),
    weekEnd: formatDate(weekEnd),
    month,
    year,
  };
}

// ═══════════════════════════════════════
// Calculate Bonus from Weekly Revenue
// ═══════════════════════════════════════
/**
 * Determines the bonus amount and tier based on weekly revenue
 * @param revenue - Total weekly revenue in SAR
 * @returns Bonus amount, tier, and eligibility status
 */
export function calculateBonus(revenue: number): BonusResult {
  // Find the matching tier
  const tier = BONUS_TIERS.find((t) => revenue >= t.min && revenue <= t.max);

  if (!tier) {
    // Fallback to 'none' tier if no match found
    return {
      amount: 0,
      tier: 'none',
      isEligible: false,
    };
  }

  return {
    amount: tier.amount,
    tier: tier.tier,
    isEligible: tier.amount > 0,
  };
}

// ═══════════════════════════════════════
// Helper: Get Week Date Range
// ═══════════════════════════════════════
/**
 * Get the start and end dates for a specific week in a month
 * Useful for querying revenues within a week
 */
export function getWeekDateRange(year: number, month: number, weekNumber: number): {
  weekStart: string;
  weekEnd: string;
} {
  // Create a date in the middle of the target week
  const weeks = [
    { num: 1, day: 4 },  // Middle of week 1
    { num: 2, day: 11 }, // Middle of week 2
    { num: 3, day: 19 }, // Middle of week 3
    { num: 4, day: 26 }, // Middle of week 4
    { num: 5, day: 30 }, // Week 5 (if exists)
  ];

  const weekDef = weeks.find((w) => w.num === weekNumber);
  if (!weekDef) {
    throw new Error(`Invalid week number: ${weekNumber}`);
  }

  // month is 1-indexed, Date constructor expects 0-indexed
  const sampleDate = new Date(year, month - 1, weekDef.day);
  const weekInfo = getWeekInfo(sampleDate);

  return {
    weekStart: weekInfo.weekStart,
    weekEnd: weekInfo.weekEnd,
  };
}
