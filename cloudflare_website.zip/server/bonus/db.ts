/**
 * Database Query Helpers for Bonus System
 * Reusable database operations for bonus management
 */

import { getDb } from '../db';
import { weeklyBonuses, bonusDetails, employees, branches, users } from '../../drizzle/schema';
import { eq, and, sql, desc } from 'drizzle-orm';

// ═══════════════════════════════════════
// Get Weekly Bonus with Employee Details
// ═══════════════════════════════════════
export async function getWeeklyBonusWithDetails(
  branchId: number,
  year: number,
  month: number,
  weekNumber: number
) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  // Get the weekly bonus record
  const [bonus] = await db
    .select({
      id: weeklyBonuses.id,
      branchId: weeklyBonuses.branchId,
      weekNumber: weeklyBonuses.weekNumber,
      weekStart: weeklyBonuses.weekStart,
      weekEnd: weeklyBonuses.weekEnd,
      month: weeklyBonuses.month,
      year: weeklyBonuses.year,
      status: weeklyBonuses.status,
      requestedAt: weeklyBonuses.requestedAt,
      requestedBy: weeklyBonuses.requestedBy,
      approvedAt: weeklyBonuses.approvedAt,
      approvedBy: weeklyBonuses.approvedBy,
      rejectedAt: weeklyBonuses.rejectedAt,
      rejectedBy: weeklyBonuses.rejectedBy,
      rejectionReason: weeklyBonuses.rejectionReason,
      totalAmount: weeklyBonuses.totalAmount,
      createdAt: weeklyBonuses.createdAt,
      updatedAt: weeklyBonuses.updatedAt,
      eligibleCount: sql<number>`(
        SELECT COUNT(*) 
        FROM ${bonusDetails} 
        WHERE ${bonusDetails.weeklyBonusId} = ${weeklyBonuses.id} 
        AND ${bonusDetails.isEligible} = 1
      )`,
    })
    .from(weeklyBonuses)
    .where(
      and(
        eq(weeklyBonuses.branchId, branchId),
        eq(weeklyBonuses.year, year),
        eq(weeklyBonuses.month, month),
        eq(weeklyBonuses.weekNumber, weekNumber)
      )
    )
    .limit(1);

  if (!bonus) {
    return null;
  }

  // Get employee details
  const employeeDetails = await db
    .select({
      id: bonusDetails.id,
      employeeId: bonusDetails.employeeId,
      employeeName: employees.name,
      employeeCode: employees.code,
      weeklyRevenue: bonusDetails.weeklyRevenue,
      bonusAmount: bonusDetails.bonusAmount,
      bonusTier: bonusDetails.bonusTier,
      isEligible: bonusDetails.isEligible,
      evaluationScore: bonusDetails.evaluationScore,
    })
    .from(bonusDetails)
    .innerJoin(employees, eq(bonusDetails.employeeId, employees.id))
    .where(eq(bonusDetails.weeklyBonusId, bonus.id))
    .orderBy(desc(bonusDetails.weeklyRevenue));

  return {
    ...bonus,
    employees: employeeDetails,
  };
}

// ═══════════════════════════════════════
// Get All Pending Bonus Requests (Admin)
// ═══════════════════════════════════════
export async function getPendingBonusRequests() {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  const requests = await db
    .select({
      id: weeklyBonuses.id,
      branchId: weeklyBonuses.branchId,
      branchName: branches.nameAr,
      weekNumber: weeklyBonuses.weekNumber,
      weekStart: weeklyBonuses.weekStart,
      weekEnd: weeklyBonuses.weekEnd,
      month: weeklyBonuses.month,
      year: weeklyBonuses.year,
      status: weeklyBonuses.status,
      requestedAt: weeklyBonuses.requestedAt,
      requestedBy: weeklyBonuses.requestedBy,
      supervisorName: users.name,
      totalAmount: weeklyBonuses.totalAmount,
      eligibleCount: sql<number>`(
        SELECT COUNT(*) 
        FROM ${bonusDetails} 
        WHERE ${bonusDetails.weeklyBonusId} = ${weeklyBonuses.id} 
        AND ${bonusDetails.isEligible} = 1
      )`,
    })
    .from(weeklyBonuses)
    .innerJoin(branches, eq(weeklyBonuses.branchId, branches.id))
    .leftJoin(users, eq(weeklyBonuses.requestedBy, users.id))
    .where(eq(weeklyBonuses.status, 'requested'))
    .orderBy(desc(weeklyBonuses.requestedAt));

  return requests;
}

// ═══════════════════════════════════════
// Get Bonus History for a Branch
// ═══════════════════════════════════════
export async function getBonusHistory(
  branchId: number,
  limit: number = 20,
  offset: number = 0
) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  const history = await db
    .select({
      id: weeklyBonuses.id,
      weekNumber: weeklyBonuses.weekNumber,
      weekStart: weeklyBonuses.weekStart,
      weekEnd: weeklyBonuses.weekEnd,
      month: weeklyBonuses.month,
      year: weeklyBonuses.year,
      status: weeklyBonuses.status,
      totalAmount: weeklyBonuses.totalAmount,
      requestedAt: weeklyBonuses.requestedAt,
      approvedAt: weeklyBonuses.approvedAt,
      rejectedAt: weeklyBonuses.rejectedAt,
      eligibleCount: sql<number>`(
        SELECT COUNT(*) 
        FROM ${bonusDetails} 
        WHERE ${bonusDetails.weeklyBonusId} = ${weeklyBonuses.id} 
        AND ${bonusDetails.isEligible} = 1
      )`,
    })
    .from(weeklyBonuses)
    .where(eq(weeklyBonuses.branchId, branchId))
    .orderBy(desc(weeklyBonuses.year), desc(weeklyBonuses.month), desc(weeklyBonuses.weekNumber))
    .limit(limit)
    .offset(offset);

  return history;
}

// ═══════════════════════════════════════
// Request Bonus Payout (Supervisor)
// ═══════════════════════════════════════
export async function requestBonusPayout(weeklyBonusId: number, supervisorId: number) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  // Check current status
  const [bonus] = await db
    .select({ status: weeklyBonuses.status })
    .from(weeklyBonuses)
    .where(eq(weeklyBonuses.id, weeklyBonusId))
    .limit(1);

  if (!bonus) {
    throw new Error('BONUS_NOT_FOUND');
  }

  if (bonus.status !== 'pending') {
    throw new Error('INVALID_STATUS: Can only request pending bonuses');
  }

  // Update status to requested
  await db
    .update(weeklyBonuses)
    .set({
      status: 'requested',
      requestedAt: new Date(),
      requestedBy: supervisorId,
      updatedAt: new Date(),
    })
    .where(eq(weeklyBonuses.id, weeklyBonusId));

  return { success: true, status: 'requested' };
}

// ═══════════════════════════════════════
// Approve Bonus (Admin)
// ═══════════════════════════════════════
export async function approveBonus(weeklyBonusId: number, adminId: number) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  // Check current status
  const [bonus] = await db
    .select({ status: weeklyBonuses.status })
    .from(weeklyBonuses)
    .where(eq(weeklyBonuses.id, weeklyBonusId))
    .limit(1);

  if (!bonus) {
    throw new Error('BONUS_NOT_FOUND');
  }

  if (bonus.status !== 'requested') {
    throw new Error('INVALID_STATUS: Can only approve requested bonuses');
  }

  // Update status to approved
  await db
    .update(weeklyBonuses)
    .set({
      status: 'approved',
      approvedAt: new Date(),
      approvedBy: adminId,
      updatedAt: new Date(),
    })
    .where(eq(weeklyBonuses.id, weeklyBonusId));

  return { success: true, status: 'approved' };
}

// ═══════════════════════════════════════
// Reject Bonus (Admin)
// ═══════════════════════════════════════
export async function rejectBonus(
  weeklyBonusId: number,
  adminId: number,
  reason: string
) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  // Check current status
  const [bonus] = await db
    .select({ status: weeklyBonuses.status })
    .from(weeklyBonuses)
    .where(eq(weeklyBonuses.id, weeklyBonusId))
    .limit(1);

  if (!bonus) {
    throw new Error('BONUS_NOT_FOUND');
  }

  if (bonus.status !== 'requested') {
    throw new Error('INVALID_STATUS: Can only reject requested bonuses');
  }

  // Update status to rejected
  await db
    .update(weeklyBonuses)
    .set({
      status: 'rejected',
      rejectedAt: new Date(),
      rejectedBy: adminId,
      rejectionReason: reason,
      updatedAt: new Date(),
    })
    .where(eq(weeklyBonuses.id, weeklyBonusId));

  // Reset to pending so it can be requested again after corrections
  await db
    .update(weeklyBonuses)
    .set({
      status: 'pending',
      updatedAt: new Date(),
    })
    .where(eq(weeklyBonuses.id, weeklyBonusId));

  return { success: true, status: 'pending', reason };
}

// ═══════════════════════════════════════
// Get Week Bonus Details (alias for getWeeklyBonusWithDetails)
// ═══════════════════════════════════════
export async function getWeekBonusDetails(
  year: number,
  month: number,
  weekNumber: number,
  branchId?: number | null
) {
  if (!branchId) {
    throw new Error('Branch ID is required');
  }
  
  return getWeeklyBonusWithDetails(branchId, year, month, weekNumber);
}

// ═══════════════════════════════════════
// Get Current Week Bonus for Branch
// ═══════════════════════════════════════
export async function getCurrentWeekBonus(branchId: number) {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const day = now.getDate();

  // Determine current week
  const weeks = [
    { num: 1, start: 1, end: 7 },
    { num: 2, start: 8, end: 15 },
    { num: 3, start: 16, end: 22 },
    { num: 4, start: 23, end: 29 },
    { num: 5, start: 30, end: 31 },
  ];

  const currentWeek = weeks.find((w) => day >= w.start && day <= w.end);
  if (!currentWeek) {
    throw new Error('Unable to determine current week');
  }

  return getWeeklyBonusWithDetails(branchId, year, month, currentWeek.num);
}


// ═══════════════════════════════════════
// Calculate Weekly Bonus from Daily Revenues
// ═══════════════════════════════════════
export async function calculateWeeklyBonus(
  branchId: number,
  year: number,
  month: number,
  weekNumber: number
) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  const { dailyRevenues, employeeRevenues } = await import('../../drizzle/schema');
  const { gte, lte } = await import('drizzle-orm');
  const Decimal = (await import('decimal.js')).default;
  type DecimalType = InstanceType<typeof Decimal>;

  // Calculate week date range
  // Week 1: 1-7, Week 2: 8-15, Week 3: 16-22, Week 4: 23-29, Week 5: 30-31
  const weekRanges: Record<number, [number, number]> = {
    1: [1, 7],
    2: [8, 15],
    3: [16, 22],
    4: [23, 29],
    5: [30, 31],
  };

  const [startDay, endDay] = weekRanges[weekNumber];
  const weekStart = new Date(year, month - 1, startDay);
  const weekEnd = new Date(year, month - 1, endDay, 23, 59, 59);

  // Get all daily revenues for this week
  const dailyRevenuesInWeek = await db
    .select()
    .from(dailyRevenues)
    .where(
      and(
        eq(dailyRevenues.branchId, branchId),
        gte(dailyRevenues.date, weekStart),
        lte(dailyRevenues.date, weekEnd)
      )
    );

  if (dailyRevenuesInWeek.length === 0) {
    throw new Error('No daily revenues found for this week');
  }

  // Get all employee revenues for these daily revenues
  const dailyRevenueIds = dailyRevenuesInWeek.map(dr => dr.id);
  const employeeRevenuesData = await db
    .select()
    .from(employeeRevenues)
    .where(
      sql`${employeeRevenues.dailyRevenueId} IN (${sql.join(dailyRevenueIds.map(id => sql`${id}`), sql`, `)})`
    );

  // Aggregate employee revenues by employee
  const employeeWeeklyTotals = new Map<number, DecimalType>();
  
  for (const empRev of employeeRevenuesData) {
    const employeeId = empRev.employeeId;
    const total = new Decimal(empRev.total);
    
    if (employeeWeeklyTotals.has(employeeId)) {
      employeeWeeklyTotals.set(employeeId, employeeWeeklyTotals.get(employeeId)!.add(total));
    } else {
      employeeWeeklyTotals.set(employeeId, total);
    }
  }

  // Calculate bonus tier for each employee
  function calculateBonusTier(weeklyRevenue: DecimalType): {
    tier: 'tier_1' | 'tier_2' | 'tier_3' | 'tier_4' | 'tier_5' | 'none';
    amount: DecimalType;
    isEligible: boolean;
  } {
    const revenue = weeklyRevenue.toNumber();
    
    if (revenue >= 2400) {
      return { tier: 'tier_5', amount: new Decimal(180), isEligible: true };
    } else if (revenue >= 2100) {
      return { tier: 'tier_4', amount: new Decimal(135), isEligible: true };
    } else if (revenue >= 1800) {
      return { tier: 'tier_3', amount: new Decimal(90), isEligible: true };
    } else if (revenue >= 1500) {
      return { tier: 'tier_2', amount: new Decimal(60), isEligible: true };
    } else if (revenue >= 1200) {
      return { tier: 'tier_1', amount: new Decimal(35), isEligible: true };
    } else {
      return { tier: 'none', amount: new Decimal(0), isEligible: false };
    }
  }

  // Calculate total bonus amount
  let totalBonusAmount = new Decimal(0);
  const bonusCalculations: Array<{
    employeeId: number;
    weeklyRevenue: DecimalType;
    bonusAmount: DecimalType;
    bonusTier: string;
    isEligible: boolean;
  }> = [];

  for (const [employeeId, weeklyRevenue] of Array.from(employeeWeeklyTotals.entries())) {
    const { tier, amount, isEligible } = calculateBonusTier(weeklyRevenue);
    
    bonusCalculations.push({
      employeeId,
      weeklyRevenue,
      bonusAmount: amount,
      bonusTier: tier,
      isEligible,
    });

    if (isEligible) {
      totalBonusAmount = totalBonusAmount.add(amount);
    }
  }

  // Check if weekly bonus already exists
  const [existingBonus] = await db
    .select()
    .from(weeklyBonuses)
    .where(
      and(
        eq(weeklyBonuses.branchId, branchId),
        eq(weeklyBonuses.year, year),
        eq(weeklyBonuses.month, month),
        eq(weeklyBonuses.weekNumber, weekNumber)
      )
    )
    .limit(1);

  let weeklyBonusId: number;

  if (existingBonus) {
    // Update existing bonus
    await db
      .update(weeklyBonuses)
      .set({
        totalAmount: totalBonusAmount.toString(),
        updatedAt: new Date(),
      })
      .where(eq(weeklyBonuses.id, existingBonus.id));

    // Delete old bonus details
    await db
      .delete(bonusDetails)
      .where(eq(bonusDetails.weeklyBonusId, existingBonus.id));

    weeklyBonusId = existingBonus.id;
  } else {
    // Create new weekly bonus record
    const [newBonus] = await db
      .insert(weeklyBonuses)
      .values({
        branchId,
        weekNumber,
        weekStart,
        weekEnd,
        month,
        year,
        status: 'pending',
        totalAmount: totalBonusAmount.toString(),
      })
      .$returningId();

    weeklyBonusId = newBonus.id;
  }

  // Insert bonus details for each employee
  for (const calc of bonusCalculations) {
    await db.insert(bonusDetails).values({
      weeklyBonusId,
      employeeId: calc.employeeId,
      weeklyRevenue: calc.weeklyRevenue.toString(),
      bonusAmount: calc.bonusAmount.toString(),
      bonusTier: calc.bonusTier as 'tier_1' | 'tier_2' | 'tier_3' | 'tier_4' | 'tier_5' | 'none',
      isEligible: calc.isEligible,
    });
  }

  return {
    weeklyBonusId,
    totalAmount: totalBonusAmount.toNumber(),
    employeeCount: bonusCalculations.length,
    eligibleCount: bonusCalculations.filter(c => c.isEligible).length,
  };
}


/**
 * Get bonus history with filters and statistics
 */
export async function getBonusHistoryWithStats(filters: {
  branchId?: number;
  year: number;
  month?: number;
  status?: 'pending' | 'requested' | 'approved' | 'rejected';
}) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  const Decimal = (await import('decimal.js')).default;

  // Build where conditions
  const conditions = [];
  conditions.push(eq(weeklyBonuses.year, filters.year));
  
  if (filters.month) {
    conditions.push(eq(weeklyBonuses.month, filters.month));
  }
  
  if (filters.branchId) {
    conditions.push(eq(weeklyBonuses.branchId, filters.branchId));
  }
  
  if (filters.status) {
    conditions.push(eq(weeklyBonuses.status, filters.status));
  }

  // Get history
  const history = await db
    .select({
      id: weeklyBonuses.id,
      weekNumber: weeklyBonuses.weekNumber,
      month: weeklyBonuses.month,
      year: weeklyBonuses.year,
      branchId: weeklyBonuses.branchId,
      branchName: branches.nameAr,
      totalAmount: weeklyBonuses.totalAmount,
      eligibleEmployees: sql<number>`(
        SELECT COUNT(*) 
        FROM ${bonusDetails} 
        WHERE ${bonusDetails.weeklyBonusId} = ${weeklyBonuses.id} 
        AND ${bonusDetails.isEligible} = 1
      )`,
      status: weeklyBonuses.status,
      createdAt: weeklyBonuses.createdAt,
    })
    .from(weeklyBonuses)
    .leftJoin(branches, eq(weeklyBonuses.branchId, branches.id))
    .where(and(...conditions))
    .orderBy(desc(weeklyBonuses.year), desc(weeklyBonuses.month), desc(weeklyBonuses.weekNumber));

  // Calculate statistics
  let totalPaid = new Decimal(0);
  let totalEmployees = 0;
  let approvedCount = 0;
  let rejectedCount = 0;
  let pendingCount = 0;

  for (const item of history) {
    if (item.status === 'approved') {
      totalPaid = totalPaid.plus(new Decimal(item.totalAmount));
      totalEmployees += item.eligibleEmployees;
      approvedCount++;
    } else if (item.status === 'rejected') {
      rejectedCount++;
    } else if (item.status === 'pending' || item.status === 'requested') {
      pendingCount++;
    }
  }

  const averagePerEmployee = totalEmployees > 0 
    ? totalPaid.dividedBy(totalEmployees).toNumber() 
    : 0;

  const totalRequests = approvedCount + rejectedCount;
  const approvalRate = totalRequests > 0 
    ? (approvedCount / totalRequests) * 100 
    : 0;

  return {
    history,
    stats: {
      totalPaid: totalPaid.toNumber(),
      averagePerEmployee,
      approvalRate,
      pendingCount,
    },
  };
}
