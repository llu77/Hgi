import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { getDb } from '../db';
import { sql } from 'drizzle-orm';
import {
  getCurrentWeekBonus,
  getWeeklyBonusWithDetails,
  getBonusHistory,
  requestBonusPayout,
  approveBonus,
  rejectBonus,
  getPendingBonusRequests,
} from './db';
import { syncBonusOnRevenueChange } from './sync';

describe('Bonus Database Operations', () => {
  let testBranchId: number;
  let testEmployeeId: number;
  let testUserId: number;
  let testWeeklyBonusId: number;

  beforeAll(async () => {
    const db = await getDb();

    // Create test branch
    const branchResult = await db.execute(
      sql.raw(`INSERT INTO branches (code, name, name_ar, is_active) VALUES ('TST-BONUS', 'Test Branch Bonus', 'فرع الاختبار', 1)`)
    );
    testBranchId = Number((branchResult as any).insertId || branchResult[0]?.insertId);

    // Create test user (manager)
    const userResult = await db.execute(
      sql.raw(`INSERT INTO users (username, name, role, branch_id, is_active) VALUES ('test_manager_bonus', 'Test Manager', 'manager', ${testBranchId}, 1)`)
    );
    testUserId = Number((userResult as any).insertId || userResult[0]?.insertId);

    // Create test employee
    const empResult = await db.execute(
      sql.raw(`INSERT INTO employees (branch_id, name, code, status) VALUES (${testBranchId}, 'Test Employee Bonus', 'EMP-BONUS-001', 'active')`)
    );
    testEmployeeId = Number((empResult as any).insertId || empResult[0]?.insertId);
  });

  afterAll(async () => {
    const db = await getDb();
    
    // Clean up test data
    await db.execute(
      sql.raw(`DELETE FROM bonus_details WHERE weekly_bonus_id IN (SELECT id FROM weekly_bonuses WHERE branch_id = ${testBranchId})`)
    );
    await db.execute(
      sql.raw(`DELETE FROM weekly_bonuses WHERE branch_id = ${testBranchId}`)
    );
    await db.execute(
      sql.raw(`DELETE FROM employees WHERE id = ${testEmployeeId}`)
    );
    await db.execute(
      sql.raw(`DELETE FROM users WHERE id = ${testUserId}`)
    );
    await db.execute(
      sql.raw(`DELETE FROM branches WHERE id = ${testBranchId}`)
    );
  });

  describe('Bonus Sync on Revenue Change', () => {
    it('should create weekly bonus record when employee revenue is added', async () => {
      const testDate = new Date('2025-12-15'); // Week 3 of December
      
      // Simulate revenue entry
      await syncBonusOnRevenueChange(testEmployeeId, testBranchId, testDate);

      // Verify weekly bonus was created
      const bonus = await getCurrentWeekBonus(testBranchId);
      expect(bonus).toBeDefined();
      expect(bonus?.weekNumber).toBe(3);
      expect(bonus?.month).toBe(12);
      expect(bonus?.year).toBe(2025);
      expect(bonus?.status).toBe('pending');

      testWeeklyBonusId = bonus!.id;
    });

    it('should update bonus when revenue changes', async () => {
      const db = await getDb();
      
      // Add revenue data for the employee
      await db.execute(
        sql.raw(`INSERT INTO employee_revenues (daily_revenue_id, employee_id, cash, network, total, created_at)
              VALUES (1, ${testEmployeeId}, '1000', '1500', '2500', '${new Date('2025-12-15').toISOString()}')`)
      );

      // Sync bonus
      await syncBonusOnRevenueChange(testEmployeeId, testBranchId, new Date('2025-12-15'));

      // Check bonus details
      const bonus = await getWeeklyBonusWithDetails(testBranchId, 2025, 12, 3);
      expect(bonus).toBeDefined();
      expect(bonus?.employees).toBeDefined();
      
      const empBonus = bonus?.employees?.find((e: any) => e.employeeId === testEmployeeId);
      expect(empBonus).toBeDefined();
      expect(Number(empBonus?.weeklyRevenue)).toBeGreaterThan(0);
    });
  });

  describe('Get Current Week Bonus', () => {
    it('should return current week bonus for branch', async () => {
      const bonus = await getCurrentWeekBonus(testBranchId);
      
      expect(bonus).toBeDefined();
      expect(bonus?.branchId).toBe(testBranchId);
      expect(bonus?.status).toBe('pending');
      expect(bonus?.weekNumber).toBeGreaterThan(0);
      expect(bonus?.weekNumber).toBeLessThanOrEqual(5);
    });

    it('should return null for branch with no bonuses', async () => {
      const bonus = await getCurrentWeekBonus(99999);
      expect(bonus).toBeNull();
    });
  });

  describe('Get Weekly Bonus With Details', () => {
    it('should return bonus with employee details', async () => {
      const bonus = await getWeeklyBonusWithDetails(testBranchId, 2025, 12, 3);
      
      expect(bonus).toBeDefined();
      expect(bonus?.branchId).toBe(testBranchId);
      expect(bonus?.employees).toBeDefined();
      expect(Array.isArray(bonus?.employees)).toBe(true);
    });

    it('should return null for non-existent week', async () => {
      const bonus = await getWeeklyBonusWithDetails(testBranchId, 2020, 1, 1);
      expect(bonus).toBeNull();
    });
  });

  describe('Request Bonus Payout', () => {
    it('should successfully request bonus payout', async () => {
      const result = await requestBonusPayout(testWeeklyBonusId, testUserId);
      
      expect(result.success).toBe(true);
      expect(result.weeklyBonusId).toBe(testWeeklyBonusId);

      // Verify status changed
      const bonus = await getCurrentWeekBonus(testBranchId);
      expect(bonus?.status).toBe('requested');
      expect(bonus?.requestedBy).toBe(testUserId);
      expect(bonus?.requestedAt).toBeDefined();
    });

    it('should fail to request already requested bonus', async () => {
      await expect(
        requestBonusPayout(testWeeklyBonusId, testUserId)
      ).rejects.toThrow('Bonus has already been requested');
    });

    it('should fail to request non-existent bonus', async () => {
      await expect(
        requestBonusPayout(99999, testUserId)
      ).rejects.toThrow('Weekly bonus not found');
    });
  });

  describe('Get Pending Bonus Requests', () => {
    it('should return all pending requests', async () => {
      const requests = await getPendingBonusRequests();
      
      expect(Array.isArray(requests)).toBe(true);
      expect(requests.length).toBeGreaterThan(0);
      
      const testRequest = requests.find((r: any) => r.id === testWeeklyBonusId);
      expect(testRequest).toBeDefined();
      expect(testRequest?.status).toBe('requested');
      expect(testRequest?.branchName).toBe('Test Branch Bonus');
    });
  });

  describe('Approve Bonus', () => {
    it('should successfully approve bonus', async () => {
      const adminUserId = testUserId; // Using same user as admin for test
      const result = await approveBonus(testWeeklyBonusId, adminUserId);
      
      expect(result.success).toBe(true);
      expect(result.weeklyBonusId).toBe(testWeeklyBonusId);

      // Verify status changed
      const bonus = await getCurrentWeekBonus(testBranchId);
      expect(bonus?.status).toBe('approved');
      expect(bonus?.approvedBy).toBe(adminUserId);
      expect(bonus?.approvedAt).toBeDefined();
    });

    it('should fail to approve already approved bonus', async () => {
      await expect(
        approveBonus(testWeeklyBonusId, testUserId)
      ).rejects.toThrow('Bonus has already been approved or rejected');
    });
  });

  describe('Reject Bonus', () => {
    it('should successfully reject bonus', async () => {
      // Create new bonus for rejection test
      const db = await getDb();
      const bonusResult = await db.execute(
        sql.raw(`INSERT INTO weekly_bonuses (
          branch_id, week_number, week_start, week_end, month, year,
          total_amount, eligible_count, status, created_at
        ) VALUES (
          ${testBranchId}, 4, '${new Date('2025-12-23').toISOString()}', '${new Date('2025-12-29').toISOString()}',
          12, 2025, '180.00', 1, 'requested', '${new Date().toISOString()}'
        )`)
      );
      const newBonusId = Number((bonusResult as any).insertId || bonusResult[0]?.insertId);

      const result = await rejectBonus(newBonusId, testUserId, 'Test rejection reason');
      
      expect(result.success).toBe(true);
      expect(result.weeklyBonusId).toBe(newBonusId);

      // Verify status changed
      const bonus = await getWeeklyBonusWithDetails(testBranchId, 2025, 12, 4);
      expect(bonus?.status).toBe('rejected');
      expect(bonus?.rejectionReason).toBe('Test rejection reason');
    });

    it('should fail to reject without reason', async () => {
      await expect(
        rejectBonus(testWeeklyBonusId, testUserId, '')
      ).rejects.toThrow('Rejection reason is required');
    });
  });

  describe('Get Bonus History', () => {
    it('should return bonus history for branch', async () => {
      const history = await getBonusHistory(testBranchId, 10, 0);
      
      expect(Array.isArray(history)).toBe(true);
      expect(history.length).toBeGreaterThan(0);
      
      // Verify sorting (most recent first)
      if (history.length > 1) {
        const first = new Date(history[0].createdAt).getTime();
        const second = new Date(history[1].createdAt).getTime();
        expect(first).toBeGreaterThanOrEqual(second);
      }
    });

    it('should respect limit parameter', async () => {
      const history = await getBonusHistory(testBranchId, 1, 0);
      expect(history.length).toBeLessThanOrEqual(1);
    });
  });
});
