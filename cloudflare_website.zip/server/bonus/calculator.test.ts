/**
 * Tests for Bonus Calculator
 * Validates week calculation and bonus tier logic
 */

import { describe, it, expect } from 'vitest';
import { getWeekInfo, calculateBonus, getWeekDateRange, BONUS_TIERS } from './calculator';

describe('Bonus Calculator', () => {
  // ═══════════════════════════════════════
  // Week Calculation Tests
  // ═══════════════════════════════════════
  describe('getWeekInfo', () => {
    it('should correctly identify week 1 (days 1-7)', () => {
      const date = new Date('2025-12-03'); // December 3rd
      const weekInfo = getWeekInfo(date);

      expect(weekInfo.weekNumber).toBe(1);
      expect(weekInfo.weekStart).toBe('2025-12-01');
      expect(weekInfo.weekEnd).toBe('2025-12-07');
      expect(weekInfo.month).toBe(12);
      expect(weekInfo.year).toBe(2025);
    });

    it('should correctly identify week 2 (days 8-15)', () => {
      const date = new Date('2025-12-10'); // December 10th
      const weekInfo = getWeekInfo(date);

      expect(weekInfo.weekNumber).toBe(2);
      expect(weekInfo.weekStart).toBe('2025-12-08');
      expect(weekInfo.weekEnd).toBe('2025-12-15');
    });

    it('should correctly identify week 3 (days 16-22)', () => {
      const date = new Date('2025-12-20'); // December 20th
      const weekInfo = getWeekInfo(date);

      expect(weekInfo.weekNumber).toBe(3);
      expect(weekInfo.weekStart).toBe('2025-12-16');
      expect(weekInfo.weekEnd).toBe('2025-12-22');
    });

    it('should correctly identify week 4 (days 23-29)', () => {
      const date = new Date('2025-12-25'); // December 25th
      const weekInfo = getWeekInfo(date);

      expect(weekInfo.weekNumber).toBe(4);
      expect(weekInfo.weekStart).toBe('2025-12-23');
      expect(weekInfo.weekEnd).toBe('2025-12-29');
    });

    it('should correctly identify week 5 (days 30-31)', () => {
      const date = new Date('2025-12-31'); // December 31st
      const weekInfo = getWeekInfo(date);

      expect(weekInfo.weekNumber).toBe(5);
      expect(weekInfo.weekStart).toBe('2025-12-30');
      expect(weekInfo.weekEnd).toBe('2025-12-31');
    });

    it('should handle February (28 days)', () => {
      const date = new Date('2025-02-28'); // Non-leap year
      const weekInfo = getWeekInfo(date);

      expect(weekInfo.weekNumber).toBe(4);
      expect(weekInfo.weekEnd).toBe('2025-02-28'); // Week 4 ends on 28th (no week 5)
    });

    it('should handle February in leap year (29 days)', () => {
      const date = new Date('2024-02-29'); // Leap year
      const weekInfo = getWeekInfo(date);

      expect(weekInfo.weekNumber).toBe(4);
      expect(weekInfo.weekEnd).toBe('2024-02-29');
    });

    it('should handle months with 30 days', () => {
      const date = new Date(2025, 10, 30); // November 30th (month is 0-indexed)
      const weekInfo = getWeekInfo(date);

      expect(weekInfo.weekNumber).toBe(5); // Day 30 is in week 5
      expect(weekInfo.weekStart).toBe('2025-11-30');
      expect(weekInfo.weekEnd).toBe('2025-11-30');
    });

    it('should correctly handle day 29 (last day of week 4)', () => {
      const date = new Date('2025-12-29'); // December 29th
      const weekInfo = getWeekInfo(date);

      expect(weekInfo.weekNumber).toBe(4);
      expect(weekInfo.weekStart).toBe('2025-12-23');
      expect(weekInfo.weekEnd).toBe('2025-12-29');
    });
  });

  // ═══════════════════════════════════════
  // Bonus Tier Calculation Tests
  // ═══════════════════════════════════════
  describe('calculateBonus', () => {
    it('should return tier_5 for revenue >= 2400 SAR', () => {
      const result1 = calculateBonus(2400);
      expect(result1.tier).toBe('tier_5');
      expect(result1.amount).toBe(180);
      expect(result1.isEligible).toBe(true);

      const result2 = calculateBonus(3000);
      expect(result2.tier).toBe('tier_5');
      expect(result2.amount).toBe(180);
    });

    it('should return tier_4 for revenue 2100-2399 SAR', () => {
      const result1 = calculateBonus(2100);
      expect(result1.tier).toBe('tier_4');
      expect(result1.amount).toBe(135);
      expect(result1.isEligible).toBe(true);

      const result2 = calculateBonus(2399);
      expect(result2.tier).toBe('tier_4');
      expect(result2.amount).toBe(135);
    });

    it('should return tier_3 for revenue 1800-2099 SAR', () => {
      const result1 = calculateBonus(1800);
      expect(result1.tier).toBe('tier_3');
      expect(result1.amount).toBe(95);
      expect(result1.isEligible).toBe(true);

      const result2 = calculateBonus(2099);
      expect(result2.tier).toBe('tier_3');
      expect(result2.amount).toBe(95);
    });

    it('should return tier_2 for revenue 1500-1799 SAR', () => {
      const result1 = calculateBonus(1500);
      expect(result1.tier).toBe('tier_2');
      expect(result1.amount).toBe(60);
      expect(result1.isEligible).toBe(true);

      const result2 = calculateBonus(1799);
      expect(result2.tier).toBe('tier_2');
      expect(result2.amount).toBe(60);
    });

    it('should return tier_1 for revenue 1200-1499 SAR', () => {
      const result1 = calculateBonus(1200);
      expect(result1.tier).toBe('tier_1');
      expect(result1.amount).toBe(35);
      expect(result1.isEligible).toBe(true);

      const result2 = calculateBonus(1499);
      expect(result2.tier).toBe('tier_1');
      expect(result2.amount).toBe(35);
    });

    it('should return none for revenue < 1200 SAR', () => {
      const result1 = calculateBonus(0);
      expect(result1.tier).toBe('none');
      expect(result1.amount).toBe(0);
      expect(result1.isEligible).toBe(false);

      const result2 = calculateBonus(1199);
      expect(result2.tier).toBe('none');
      expect(result2.amount).toBe(0);
      expect(result2.isEligible).toBe(false);
    });

    it('should handle edge cases at tier boundaries', () => {
      // Just below tier_1
      const below = calculateBonus(1199.99);
      expect(below.tier).toBe('none');
      expect(below.amount).toBe(0);

      // Exactly at tier_1 start
      const atStart = calculateBonus(1200);
      expect(atStart.tier).toBe('tier_1');
      expect(atStart.amount).toBe(35);

      // Exactly at tier_1 end
      const atEnd = calculateBonus(1499);
      expect(atEnd.tier).toBe('tier_1');
      expect(atEnd.amount).toBe(35);

      // Just above tier_1
      const above = calculateBonus(1500);
      expect(above.tier).toBe('tier_2');
      expect(above.amount).toBe(60);
    });
  });

  // ═══════════════════════════════════════
  // Week Date Range Helper Tests
  // ═══════════════════════════════════════
  describe('getWeekDateRange', () => {
    it('should return correct date range for week 1', () => {
      const range = getWeekDateRange(2025, 12, 1);
      expect(range.weekStart).toBe('2025-12-01');
      expect(range.weekEnd).toBe('2025-12-07');
    });

    it('should return correct date range for week 3', () => {
      const range = getWeekDateRange(2025, 12, 3);
      expect(range.weekStart).toBe('2025-12-16');
      expect(range.weekEnd).toBe('2025-12-22');
    });

    it('should return correct date range for week 5', () => {
      const range = getWeekDateRange(2025, 12, 5);
      expect(range.weekStart).toBe('2025-12-30');
      expect(range.weekEnd).toBe('2025-12-31');
    });

    it('should handle February week 5 (non-existent in 28-day month)', () => {
      const range = getWeekDateRange(2025, 2, 4);
      expect(range.weekEnd).toBe('2025-02-28');
    });
  });

  // ═══════════════════════════════════════
  // Bonus Tiers Configuration Tests
  // ═══════════════════════════════════════
  describe('BONUS_TIERS configuration', () => {
    it('should have 6 tiers defined', () => {
      expect(BONUS_TIERS).toHaveLength(6);
    });

    it('should have tiers in descending order by minimum', () => {
      for (let i = 0; i < BONUS_TIERS.length - 1; i++) {
        expect(BONUS_TIERS[i].min).toBeGreaterThan(BONUS_TIERS[i + 1].min);
      }
    });

    it('should have correct tier amounts', () => {
      const tierAmounts = {
        tier_5: 180,
        tier_4: 135,
        tier_3: 95,
        tier_2: 60,
        tier_1: 35,
        none: 0,
      };

      BONUS_TIERS.forEach((tier) => {
        expect(tier.amount).toBe(tierAmounts[tier.tier]);
      });
    });
  });
});
