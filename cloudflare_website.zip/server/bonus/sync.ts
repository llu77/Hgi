/**
 * Bonus Sync Mechanism
 * Automatically updates bonus calculations when revenues change
 */

import { getDb } from '../db';
import { weeklyBonuses, bonusDetails, employeeRevenues, dailyRevenues } from '../../drizzle/schema';
import { getWeekInfo, calculateBonus } from './calculator';
import { eq, and, between, sql } from 'drizzle-orm';

// ═══════════════════════════════════════
// Sync Bonus on Revenue Change
// ═══════════════════════════════════════
/**
 * Called automatically when a revenue entry is added or modified
 * Updates or creates bonus records for the affected employee and week
 * 
 * @param employeeId - ID of the employee whose revenue changed
 * @param branchId - ID of the branch
 * @param revenueDate - Date of the revenue entry
 * @throws Error if bonus is already approved (cannot modify)
 */
export async function syncBonusOnRevenueChange(
  employeeId: number,
  branchId: number,
  revenueDate: Date
): Promise<void> {
  // 1️⃣ Determine which week this revenue belongs to
  const { weekNumber, weekStart, weekEnd, month, year } = getWeekInfo(revenueDate);

  // 2️⃣ Find or create the weekly bonus record
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  let weeklyBonus = await db
    .select()
    .from(weeklyBonuses)
    .where(
      and(
        eq(weeklyBonuses.branchId, branchId),
        eq(weeklyBonuses.year, year),
        eq(weeklyBonuses.month, month),
        eq(weeklyBonuses.weekNumber, weekNumber)
      )
    )
    .limit(1);

  if (weeklyBonus.length === 0) {
    // Create new weekly bonus record
    const [newBonus] = await db.insert(weeklyBonuses).values({
      branchId,
      weekNumber,
      weekStart: new Date(weekStart),
      weekEnd: new Date(weekEnd),
      month,
      year,
      status: 'pending',
      totalAmount: '0.00',
    });

    weeklyBonus = await db
      .select()
      .from(weeklyBonuses)
      .where(eq(weeklyBonuses.id, newBonus.insertId))
      .limit(1);
  }

  const bonus = weeklyBonus[0];

  // ⚠️ Prevent modification if already approved
  if (bonus.status === 'approved') {
    throw new Error('BONUS_ALREADY_APPROVED: Cannot modify bonus after approval');
  }

  // 3️⃣ Calculate total weekly revenue for this employee
  // Must JOIN with dailyRevenues to get the actual revenue date
  const weeklyRevenueResult = await db
    .select({
      total: sql<number>`COALESCE(SUM(${employeeRevenues.total}), 0)`,
    })
    .from(employeeRevenues)
    .innerJoin(dailyRevenues, eq(employeeRevenues.dailyRevenueId, dailyRevenues.id))
    .where(
      and(
        eq(employeeRevenues.employeeId, employeeId),
        eq(dailyRevenues.branchId, branchId),
        between(
          dailyRevenues.date,
          new Date(weekStart),
          new Date(weekEnd)
        )
      )
    );

  const weeklyRevenue = Number(weeklyRevenueResult[0]?.total || 0);

  // 4️⃣ Calculate bonus based on weekly revenue
  const { amount, tier, isEligible } = calculateBonus(weeklyRevenue);

  // 5️⃣ Upsert bonus detail for this employee
  const existingDetail = await db
    .select()
    .from(bonusDetails)
    .where(
      and(
        eq(bonusDetails.weeklyBonusId, bonus.id),
        eq(bonusDetails.employeeId, employeeId)
      )
    )
    .limit(1);

  if (existingDetail.length > 0) {
    // Update existing record
    await db
      .update(bonusDetails)
      .set({
        weeklyRevenue: weeklyRevenue.toString(),
        bonusAmount: amount.toString(),
        bonusTier: tier,
        isEligible,
        updatedAt: new Date(),
      })
      .where(eq(bonusDetails.id, existingDetail[0].id));
  } else {
    // Insert new record
    await db.insert(bonusDetails).values({
      weeklyBonusId: bonus.id,
      employeeId,
      weeklyRevenue: weeklyRevenue.toString(),
      bonusAmount: amount.toString(),
      bonusTier: tier,
      isEligible,
    });
  }

  // 6️⃣ Recalculate total bonus amount for the week
  const totalBonusResult = await db
    .select({
      total: sql<number>`COALESCE(SUM(${bonusDetails.bonusAmount}), 0)`,
    })
    .from(bonusDetails)
    .where(eq(bonusDetails.weeklyBonusId, bonus.id));

  const totalBonus = Number(totalBonusResult[0]?.total || 0);

  await db
    .update(weeklyBonuses)
    .set({
      totalAmount: totalBonus.toString(),
      updatedAt: new Date(),
    })
    .where(eq(weeklyBonuses.id, bonus.id));
}

// ═══════════════════════════════════════
// Recalculate All Bonuses for a Week
// ═══════════════════════════════════════
/**
 * Recalculates bonuses for all employees in a specific week
 * Useful when revenues are bulk-imported or corrected
 * 
 * @param branchId - ID of the branch
 * @param year - Year (e.g., 2025)
 * @param month - Month (1-12)
 * @param weekNumber - Week number (1-5)
 */
export async function recalculateWeekBonuses(
  branchId: number,
  year: number,
  month: number,
  weekNumber: number
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  // Find the weekly bonus record
  const [bonus] = await db
    .select()
    .from(weeklyBonuses)
    .where(
      and(
        eq(weeklyBonuses.branchId, branchId),
        eq(weeklyBonuses.year, year),
        eq(weeklyBonuses.month, month),
        eq(weeklyBonuses.weekNumber, weekNumber)
      )
    )
    .limit(1);

  if (!bonus) {
    throw new Error('WEEKLY_BONUS_NOT_FOUND');
  }

  if (bonus.status === 'approved') {
    throw new Error('BONUS_ALREADY_APPROVED: Cannot recalculate approved bonus');
  }

  // Get all employee revenue details for this week
  const weekStart = bonus.weekStart;
  const weekEnd = bonus.weekEnd;

  // Must JOIN with dailyRevenues to filter by actual revenue date
  const employeeRevenuesForWeek = await db
    .select({
      employeeId: employeeRevenues.employeeId,
      total: sql<number>`SUM(${employeeRevenues.total})`,
    })
    .from(employeeRevenues)
    .innerJoin(dailyRevenues, eq(employeeRevenues.dailyRevenueId, dailyRevenues.id))
    .where(
      and(
        eq(dailyRevenues.branchId, branchId),
        between(
          dailyRevenues.date,
          weekStart,
          weekEnd
        )
      )
    )
    .groupBy(employeeRevenues.employeeId);

  // Recalculate bonus for each employee
  for (const empRevenue of employeeRevenuesForWeek) {
    const weeklyRevenue = Number(empRevenue.total || 0);
    const { amount, tier, isEligible } = calculateBonus(weeklyRevenue);

    // Upsert bonus detail
    const existingDetail = await db
      .select()
      .from(bonusDetails)
      .where(
        and(
          eq(bonusDetails.weeklyBonusId, bonus.id),
          eq(bonusDetails.employeeId, empRevenue.employeeId)
        )
      )
      .limit(1);

    if (existingDetail.length > 0) {
      await db
        .update(bonusDetails)
        .set({
          weeklyRevenue: weeklyRevenue.toString(),
          bonusAmount: amount.toString(),
          bonusTier: tier,
          isEligible,
          updatedAt: new Date(),
        })
        .where(eq(bonusDetails.id, existingDetail[0].id));
    } else {
      await db.insert(bonusDetails).values({
        weeklyBonusId: bonus.id,
        employeeId: empRevenue.employeeId,
        weeklyRevenue: weeklyRevenue.toString(),
        bonusAmount: amount.toString(),
        bonusTier: tier,
        isEligible,
      });
    }
  }

  // Recalculate total
  const totalBonusResult = await db
    .select({
      total: sql<number>`COALESCE(SUM(${bonusDetails.bonusAmount}), 0)`,
    })
    .from(bonusDetails)
    .where(eq(bonusDetails.weeklyBonusId, bonus.id));

  const totalBonus = Number(totalBonusResult[0]?.total || 0);

  await db
    .update(weeklyBonuses)
    .set({
      totalAmount: totalBonus.toString(),
      updatedAt: new Date(),
    })
    .where(eq(weeklyBonuses.id, bonus.id));
}
