/**
 * Database Query Helpers for Revenue System
 * Reusable database operations for revenue management
 */

import { getDb } from '../db';
import { dailyRevenues, branches } from '../../drizzle/schema';
import { eq, and, gte, lte, desc } from 'drizzle-orm';

// ═══════════════════════════════════════
// Get Daily Revenues List with Filters
// ═══════════════════════════════════════
export async function getDailyRevenuesList(filters: {
  branchId?: number;
  startDate?: string;
  endDate?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  // Build where conditions
  const conditions = [];
  
  if (filters.branchId) {
    conditions.push(eq(dailyRevenues.branchId, filters.branchId));
  }
  
  if (filters.startDate) {
    conditions.push(gte(dailyRevenues.date, new Date(filters.startDate)));
  }
  
  if (filters.endDate) {
    conditions.push(lte(dailyRevenues.date, new Date(filters.endDate)));
  }

  const revenues = await db
    .select({
      id: dailyRevenues.id,
      branchId: dailyRevenues.branchId,
      branchName: branches.nameAr,
      date: dailyRevenues.date,
      cash: dailyRevenues.cash,
      network: dailyRevenues.network,
      balance: dailyRevenues.balance,
      total: dailyRevenues.total,
      isMatched: dailyRevenues.isMatched,
      unmatchReason: dailyRevenues.unmatchReason,
      createdAt: dailyRevenues.createdAt,
      updatedAt: dailyRevenues.updatedAt,
    })
    .from(dailyRevenues)
    .innerJoin(branches, eq(dailyRevenues.branchId, branches.id))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(dailyRevenues.date), desc(dailyRevenues.createdAt));

  return revenues;
}
