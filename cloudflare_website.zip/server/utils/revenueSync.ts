/**
 * Revenue Synchronization Utility
 * Automatically reflects revenue data from daily_revenues and employee_revenues
 * into weekly bonus calculations
 */

import { getDb } from "../db";
import { dailyRevenues, employeeRevenues, weeklyBonuses, bonusDetails, employees } from "../../drizzle/schema";
import { eq, and, gte, lte, sql } from "drizzle-orm";

/**
 * Calculate which week a given day belongs to
 * Week 1: Days 1-7
 * Week 2: Days 8-15
 * Week 3: Days 16-22
 * Week 4: Days 23-29
 * Week 5: Days 30-31 (remaining days)
 */
export function getWeekNumber(day: number): 1 | 2 | 3 | 4 | 5 {
  if (day >= 1 && day <= 7) return 1;
  if (day >= 8 && day <= 15) return 2;
  if (day >= 16 && day <= 22) return 3;
  if (day >= 23 && day <= 29) return 4;
  return 5; // Days 30-31
}

/**
 * Get the date range for a specific week
 */
export function getWeekDateRange(weekNumber: number, month: number, year: number): { start: Date; end: Date } {
  const ranges: Record<number, { startDay: number; endDay: number }> = {
    1: { startDay: 1, endDay: 7 },
    2: { startDay: 8, endDay: 15 },
    3: { startDay: 16, endDay: 22 },
    4: { startDay: 23, endDay: 29 },
    5: { startDay: 30, endDay: new Date(year, month, 0).getDate() }, // Last day of month
  };

  const range = ranges[weekNumber];
  const start = new Date(year, month - 1, range.startDay, 0, 0, 0);
  const end = new Date(year, month - 1, range.endDay, 23, 59, 59);

  return { start, end };
}

/**
 * Check if today is the last day of a week
 */
export function isLastDayOfWeek(date: Date = new Date()): { isLast: boolean; weekNumber: number } {
  const day = date.getDate();
  const lastDayOfMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  
  const weekEndDays = [7, 15, 22, 29, lastDayOfMonth];
  const weekNumber = getWeekNumber(day);
  
  return {
    isLast: weekEndDays.includes(day),
    weekNumber
  };
}

/**
 * Sync revenue data for a specific week
 * This function aggregates employee revenues from daily_revenues and employee_revenues tables
 */
export async function syncWeeklyRevenue(
  branchId: number,
  weekNumber: number,
  month: number,
  year: number
): Promise<{ success: boolean; message: string; data?: any }> {
  const db = await getDb();
  if (!db) {
    return { success: false, message: 'Database connection failed' };
  }
  
  try {
    const { start, end } = getWeekDateRange(weekNumber, month, year);

    console.log(`[Revenue Sync] Syncing week ${weekNumber} for branch ${branchId}, ${month}/${year}`);
    console.log(`[Revenue Sync] Date range: ${start.toISOString()} to ${end.toISOString()}`);

    // Get all active employees for this branch
    
    const branchEmployees = await db
      .select()
      .from(employees)
      .where(and(
        eq(employees.branchId, branchId),
        eq(employees.isActive, true)
      ));

    if (branchEmployees.length === 0) {
      return {
        success: false,
        message: `No active employees found for branch ${branchId}`
      };
    }

    // Get daily revenues in this date range
    const dailyRevenuesInRange = await db
      .select()
      .from(dailyRevenues)
      .where(and(
        eq(dailyRevenues.branchId, branchId),
        gte(dailyRevenues.date, start),
        lte(dailyRevenues.date, end)
      ));

    if (dailyRevenuesInRange.length === 0) {
      console.log(`[Revenue Sync] No daily revenues found for this period`);
    }

    // Get employee revenues for these daily revenues
    const dailyRevenueIds = dailyRevenuesInRange.map((dr: any) => dr.id);
    
    let employeeRevenueData: any[] = [];
    if (dailyRevenueIds.length > 0) {
      employeeRevenueData = await db
        .select({
          employeeId: employeeRevenues.employeeId,
          totalRevenue: sql<number>`SUM(${employeeRevenues.total})`,
        })
        .from(employeeRevenues)
        .where(sql`${employeeRevenues.dailyRevenueId} IN (${sql.join(dailyRevenueIds, sql`, `)})`)
        .groupBy(employeeRevenues.employeeId);
    }

    // Calculate total branch revenue for the week
    const totalBranchRevenue = employeeRevenueData.reduce((sum, emp) => sum + Number(emp.totalRevenue || 0), 0);

    // Check if weekly bonus record exists
    const existingWeeklyBonus = await db
      .select()
      .from(weeklyBonuses)
      .where(and(
        eq(weeklyBonuses.branchId, branchId),
        eq(weeklyBonuses.weekNumber, weekNumber),
        eq(weeklyBonuses.month, month),
        eq(weeklyBonuses.year, year)
      ))
      .limit(1);

    let weeklyBonusId: number;

    if (existingWeeklyBonus.length > 0) {
      // Update existing record
      weeklyBonusId = existingWeeklyBonus[0].id;
      
      await db
        .update(weeklyBonuses)
        .set({
          totalAmount: totalBranchRevenue.toString(),
          updatedAt: new Date(),
        })
        .where(eq(weeklyBonuses.id, weeklyBonusId));

      console.log(`[Revenue Sync] Updated existing weekly bonus record #${weeklyBonusId}`);
    } else {
      // Create new record
      const [newWeeklyBonus] = await db
        .insert(weeklyBonuses)
        .values({
          branchId,
          weekNumber,
          weekStart: start,
          weekEnd: end,
          month,
          year,
          status: "pending",
          totalAmount: totalBranchRevenue.toString(),
        })
        .$returningId();

      weeklyBonusId = newWeeklyBonus.id;
      console.log(`[Revenue Sync] Created new weekly bonus record #${weeklyBonusId}`);
    }

    // Sync bonus details for each employee
    for (const empRevenue of employeeRevenueData) {
      const weeklyRevenue = Number(empRevenue.totalRevenue || 0);
      
      // Calculate bonus tier based on revenue
      let bonusTier: "tier_1" | "tier_2" | "tier_3" | "tier_4" | "tier_5" | "none" = "none";
      let bonusAmount = 0;

      if (weeklyRevenue >= 2400) {
        bonusTier = "tier_5";
        bonusAmount = 180;
      } else if (weeklyRevenue >= 2100) {
        bonusTier = "tier_4";
        bonusAmount = 135;
      } else if (weeklyRevenue >= 1800) {
        bonusTier = "tier_3";
        bonusAmount = 95;
      } else if (weeklyRevenue >= 1500) {
        bonusTier = "tier_2";
        bonusAmount = 60;
      } else if (weeklyRevenue >= 1200) {
        bonusTier = "tier_1";
        bonusAmount = 35;
      }

      const isEligible = bonusAmount > 0;

      // Check if bonus detail exists
      const existingDetail = await db
        .select()
        .from(bonusDetails)
        .where(and(
          eq(bonusDetails.weeklyBonusId, weeklyBonusId),
          eq(bonusDetails.employeeId, empRevenue.employeeId)
        ))
        .limit(1);

      if (existingDetail.length > 0) {
        // Update existing
        await db
          .update(bonusDetails)
          .set({
            weeklyRevenue: weeklyRevenue.toString(),
            bonusAmount: bonusAmount.toString(),
            bonusTier,
            isEligible,
            updatedAt: new Date(),
          })
          .where(eq(bonusDetails.id, existingDetail[0].id));
      } else {
        // Insert new
        await db
          .insert(bonusDetails)
          .values({
            weeklyBonusId,
            employeeId: empRevenue.employeeId,
            weeklyRevenue: weeklyRevenue.toString(),
            bonusAmount: bonusAmount.toString(),
            bonusTier,
            isEligible,
          });
      }
    }

    return {
      success: true,
      message: `Successfully synced week ${weekNumber} for branch ${branchId}`,
      data: {
        weeklyBonusId,
        totalRevenue: totalBranchRevenue,
        employeeCount: employeeRevenueData.length,
      }
    };

  } catch (error) {
    console.error(`[Revenue Sync] Error:`, error);
    return {
      success: false,
      message: `Failed to sync revenue: ${error instanceof Error ? error.message : 'Unknown error'}`
    };
  }
}

/**
 * Sync all weeks for a given month
 */
export async function syncMonthlyRevenue(
  branchId: number,
  month: number,
  year: number
): Promise<{ success: boolean; message: string; results?: any[] }> {
  const results = [];

  for (let weekNumber = 1; weekNumber <= 5; weekNumber++) {
    const result = await syncWeeklyRevenue(branchId, weekNumber, month, year);
    results.push({ weekNumber, ...result });
  }

  const allSuccess = results.every(r => r.success);

  return {
    success: allSuccess,
    message: allSuccess 
      ? `Successfully synced all weeks for ${month}/${year}`
      : `Some weeks failed to sync for ${month}/${year}`,
    results
  };
}
