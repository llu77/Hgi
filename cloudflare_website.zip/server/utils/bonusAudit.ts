/**
 * Bonus Audit Logging Utility
 * Tracks all status changes and actions on bonus records
 */

import { getDb } from '../db';
import { bonusAuditLog, type InsertBonusAuditLog } from '../../drizzle/schema';

/**
 * Log an action on a bonus record
 */
export async function logBonusAction(params: {
  weeklyBonusId: number;
  action: string;
  oldStatus?: string;
  newStatus?: string;
  performedBy: number;
  details?: string;
  metadata?: Record<string, any>;
}): Promise<{ success: boolean; message: string }> {
  try {
    const db = await getDb();
    if (!db) {
      return { success: false, message: 'Database connection failed' };
    }

    const auditEntry: InsertBonusAuditLog = {
      weeklyBonusId: params.weeklyBonusId,
      action: params.action,
      oldStatus: params.oldStatus || null,
      newStatus: params.newStatus || null,
      performedBy: params.performedBy,
      details: params.details || null,
      metadata: params.metadata ? JSON.stringify(params.metadata) : null,
    };

    await db.insert(bonusAuditLog).values(auditEntry);

    console.log(`[Audit] Logged action "${params.action}" for bonus #${params.weeklyBonusId}`);

    return {
      success: true,
      message: 'Audit log created successfully'
    };

  } catch (error) {
    console.error('[Audit] Failed to log action:', error);
    return {
      success: false,
      message: `Failed to create audit log: ${error instanceof Error ? error.message : 'Unknown error'}`
    };
  }
}

/**
 * Log bonus request action
 */
export async function logBonusRequest(
  weeklyBonusId: number,
  requestedBy: number,
  metadata?: Record<string, any>
) {
  return logBonusAction({
    weeklyBonusId,
    action: 'bonus_requested',
    oldStatus: 'pending',
    newStatus: 'requested',
    performedBy: requestedBy,
    details: 'Employee requested bonus for this week',
    metadata
  });
}

/**
 * Log bonus approval action
 */
export async function logBonusApproval(
  weeklyBonusId: number,
  approvedBy: number,
  metadata?: Record<string, any>
) {
  return logBonusAction({
    weeklyBonusId,
    action: 'bonus_approved',
    oldStatus: 'requested',
    newStatus: 'approved',
    performedBy: approvedBy,
    details: 'Admin approved bonus request',
    metadata
  });
}

/**
 * Log bonus rejection action
 */
export async function logBonusRejection(
  weeklyBonusId: number,
  rejectedBy: number,
  reason: string,
  metadata?: Record<string, any>
) {
  return logBonusAction({
    weeklyBonusId,
    action: 'bonus_rejected',
    oldStatus: 'requested',
    newStatus: 'rejected',
    performedBy: rejectedBy,
    details: `Admin rejected bonus request. Reason: ${reason}`,
    metadata: {
      ...metadata,
      rejectionReason: reason
    }
  });
}

/**
 * Log revenue sync action
 */
export async function logRevenueSync(
  weeklyBonusId: number,
  syncedBy: number,
  metadata?: Record<string, any>
) {
  return logBonusAction({
    weeklyBonusId,
    action: 'revenue_synced',
    performedBy: syncedBy,
    details: 'Revenue data synchronized from daily revenues',
    metadata
  });
}

/**
 * Log bonus calculation action
 */
export async function logBonusCalculation(
  weeklyBonusId: number,
  calculatedBy: number,
  metadata?: Record<string, any>
) {
  return logBonusAction({
    weeklyBonusId,
    action: 'bonus_calculated',
    performedBy: calculatedBy,
    details: 'Bonus amounts calculated for employees',
    metadata
  });
}

/**
 * Get audit history for a bonus record
 */
export async function getBonusAuditHistory(weeklyBonusId: number) {
  try {
    const db = await getDb();
    if (!db) {
      return { success: false, message: 'Database connection failed', data: [] };
    }

    const { eq } = await import('drizzle-orm');
    const { bonusAuditLog: auditTable } = await import('../../drizzle/schema');

    const history = await db
      .select()
      .from(auditTable)
      .where(eq(auditTable.weeklyBonusId, weeklyBonusId))
      .orderBy(auditTable.performedAt);

    return {
      success: true,
      message: 'Audit history retrieved',
      data: history.map(entry => ({
        ...entry,
        metadata: entry.metadata ? JSON.parse(entry.metadata) : null
      }))
    };

  } catch (error) {
    console.error('[Audit] Failed to get history:', error);
    return {
      success: false,
      message: `Failed to retrieve audit history: ${error instanceof Error ? error.message : 'Unknown error'}`,
      data: []
    };
  }
}
