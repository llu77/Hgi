/**
 * Daily Revenue Synchronization Cron Job
 * Runs every day at midnight to sync revenue data into weekly bonus calculations
 */

import cron from 'node-cron';
import { getDb } from '../db';
import { branches } from '../../drizzle/schema';
import { syncWeeklyRevenue, getWeekNumber } from '../utils/revenueSync';
import { eq } from 'drizzle-orm';

/**
 * Start the daily revenue sync cron job
 * Schedule: Every day at 00:00 (midnight)
 */
export function startRevenueSyncCron() {
  // Run at midnight every day: '0 0 * * *'
  cron.schedule('0 0 * * *', async () => {
    console.log('═══════════════════════════════════════════════════════');
    console.log(`[Cron] Daily Revenue Sync started at ${new Date().toISOString()}`);
    console.log('═══════════════════════════════════════════════════════');

    try {
      const db = await getDb();
      if (!db) {
        console.error('[Cron] Database connection failed');
        return;
      }

      // Get all active branches
      const activeBranches = await db
        .select()
        .from(branches)
        .where(eq(branches.isActive, true));

      if (activeBranches.length === 0) {
        console.log('[Cron] No active branches found');
        return;
      }

      console.log(`[Cron] Found ${activeBranches.length} active branches`);

      const today = new Date();
      const weekNumber = getWeekNumber(today.getDate());
      const month = today.getMonth() + 1; // JavaScript months are 0-indexed
      const year = today.getFullYear();

      console.log(`[Cron] Current period: Week ${weekNumber}, ${month}/${year}`);

      // Sync revenue for each branch
      const results = [];
      for (const branch of activeBranches) {
        console.log(`[Cron] Syncing branch: ${branch.name} (ID: ${branch.id})`);
        
        const result = await syncWeeklyRevenue(
          branch.id,
          weekNumber,
          month,
          year
        );

        results.push({
          branchId: branch.id,
          branchName: branch.name,
          ...result
        });

        if (result.success) {
          console.log(`[Cron] ✓ ${branch.name}: ${result.message}`);
        } else {
          console.error(`[Cron] ✗ ${branch.name}: ${result.message}`);
        }
      }

      // Summary
      const successCount = results.filter(r => r.success).length;
      const failCount = results.filter(r => !r.success).length;

      console.log('═══════════════════════════════════════════════════════');
      console.log(`[Cron] Daily Revenue Sync completed`);
      console.log(`[Cron] Success: ${successCount} | Failed: ${failCount}`);
      console.log('═══════════════════════════════════════════════════════');

    } catch (error) {
      console.error('[Cron] Fatal error during revenue sync:', error);
    }
  });

  console.log('[Cron] Revenue sync cron job started (runs daily at midnight)');
}

/**
 * Manual trigger for testing purposes
 * Can be called via API endpoint or CLI
 */
export async function triggerManualSync(): Promise<{
  success: boolean;
  message: string;
  results: any[];
}> {
  console.log('[Manual Sync] Triggered by user');

  try {
    const db = await getDb();
    if (!db) {
      return {
        success: false,
        message: 'Database connection failed',
        results: []
      };
    }

    const activeBranches = await db
      .select()
      .from(branches)
      .where(eq(branches.isActive, true));

    if (activeBranches.length === 0) {
      return {
        success: false,
        message: 'No active branches found',
        results: []
      };
    }

    const today = new Date();
    const weekNumber = getWeekNumber(today.getDate());
    const month = today.getMonth() + 1;
    const year = today.getFullYear();

    const results = [];
    for (const branch of activeBranches) {
      const result = await syncWeeklyRevenue(
        branch.id,
        weekNumber,
        month,
        year
      );

      results.push({
        branchId: branch.id,
        branchName: branch.name,
        ...result
      });
    }

    const successCount = results.filter(r => r.success).length;
    const allSuccess = successCount === results.length;

    return {
      success: allSuccess,
      message: allSuccess
        ? `Successfully synced ${successCount} branches`
        : `Synced ${successCount}/${results.length} branches`,
      results
    };

  } catch (error) {
    return {
      success: false,
      message: `Sync failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      results: []
    };
  }
}
