/**
 * Email Template: Unmatched Revenue Alert
 * Sent when a daily revenue entry has isMatched = false
 */

interface UnmatchedRevenueData {
  branchName: string;
  date: string;
  cash: number;
  network: number;
  total: number;
  balance: number;
  unmatchReason: string;
  managerName: string;
}

export function generateUnmatchedRevenueAlert(data: UnmatchedRevenueData): string {
  return `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>تنبيه: إيراد غير متطابق</title>
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
          
          <!-- Header with Symbol AI Branding -->
          <tr>
            <td style="background: linear-gradient(135deg, #c19a5b 0%, #9b7a47 100%); padding: 40px 30px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: 700;">
                ⚠️ تنبيه: إيراد غير متطابق
              </h1>
              <p style="margin: 10px 0 0 0; color: #f0e6d6; font-size: 16px;">
                Symbol AI - نظام إدارة الفروع المتكامل
              </p>
            </td>
          </tr>
          
          <!-- Main Content -->
          <tr>
            <td style="padding: 40px 30px;">
              <p style="margin: 0 0 20px 0; font-size: 18px; color: #333; line-height: 1.6;">
                عزيزي <strong>${data.managerName}</strong>،
              </p>
              
              <p style="margin: 0 0 25px 0; font-size: 16px; color: #555; line-height: 1.8;">
                تم تسجيل إيراد يومي <strong style="color: #d9534f;">غير متطابق</strong> في فرع <strong>${data.branchName}</strong>. 
                يرجى مراجعة البيانات التالية واتخاذ الإجراء اللازم:
              </p>
              
              <!-- Revenue Details Card -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #fff8f0; border-right: 4px solid #c19a5b; border-radius: 8px; margin-bottom: 25px;">
                <tr>
                  <td style="padding: 25px;">
                    <table width="100%" cellpadding="8" cellspacing="0">
                      <tr>
                        <td style="font-size: 15px; color: #666; padding: 8px 0;">📅 <strong>التاريخ:</strong></td>
                        <td style="font-size: 15px; color: #333; text-align: left; padding: 8px 0;">${data.date}</td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #666; padding: 8px 0;">🏢 <strong>الفرع:</strong></td>
                        <td style="font-size: 15px; color: #333; text-align: left; padding: 8px 0;">${data.branchName}</td>
                      </tr>
                      <tr style="border-top: 1px solid #e0d4c0;">
                        <td style="font-size: 15px; color: #666; padding: 12px 0 8px 0;">💵 <strong>الكاش:</strong></td>
                        <td style="font-size: 15px; color: #333; text-align: left; padding: 12px 0 8px 0;">${data.cash.toFixed(2)} ر.س</td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #666; padding: 8px 0;">💳 <strong>الشبكة:</strong></td>
                        <td style="font-size: 15px; color: #333; text-align: left; padding: 8px 0;">${data.network.toFixed(2)} ر.س</td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #666; padding: 8px 0;">📊 <strong>المجموع:</strong></td>
                        <td style="font-size: 16px; color: #2c7a3f; font-weight: 600; text-align: left; padding: 8px 0;">${data.total.toFixed(2)} ر.س</td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #666; padding: 8px 0;">⚖️ <strong>الموازنة:</strong></td>
                        <td style="font-size: 16px; color: #d9534f; font-weight: 600; text-align: left; padding: 8px 0;">${data.balance.toFixed(2)} ر.س</td>
                      </tr>
                      <tr style="border-top: 1px solid #e0d4c0;">
                        <td colspan="2" style="padding: 12px 0 0 0;">
                          <p style="margin: 0; font-size: 14px; color: #666;"><strong>سبب عدم التطابق:</strong></p>
                          <p style="margin: 8px 0 0 0; font-size: 15px; color: #d9534f; background-color: #fff; padding: 12px; border-radius: 6px; border-right: 3px solid #d9534f;">
                            ${data.unmatchReason || "لم يتم تحديد السبب"}
                          </p>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
              
              <!-- Call to Action -->
              <table width="100%" cellpadding="0" cellspacing="0" style="margin: 30px 0;">
                <tr>
                  <td align="center">
                    <a href="https://branches.symbolai.net/revenues" 
                       style="display: inline-block; background-color: #c19a5b; color: #ffffff; text-decoration: none; padding: 14px 40px; border-radius: 8px; font-size: 16px; font-weight: 600; box-shadow: 0 2px 8px rgba(193, 154, 91, 0.3);">
                      مراجعة الإيرادات الآن
                    </a>
                  </td>
                </tr>
              </table>
              
              <p style="margin: 25px 0 0 0; font-size: 14px; color: #888; line-height: 1.6;">
                <strong>ملاحظة:</strong> يرجى التحقق من البيانات المدخلة وتصحيح الأخطاء إن وجدت. في حال استمرار المشكلة، يرجى التواصل مع الدعم الفني.
              </p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #2c2c2c; padding: 30px; text-align: center;">
              <p style="margin: 0 0 8px 0; font-size: 14px; color: #c19a5b; font-weight: 600;">
                Symbol AI © 2025
              </p>
              <p style="margin: 0 0 4px 0; font-size: 13px; color: #999;">
                جميع الحقوق محفوظة لصالح Symbol AI | مراقب النظام
              </p>
              <p style="margin: 0; font-size: 13px; color: #999;">
                All Rights Reserved to Symbol AI | System Monitor
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();
}
