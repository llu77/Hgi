/**
 * Email Template: Missing Revenue Reminder
 * Sent daily at 2:00 AM if no revenue was entered for the previous day
 */

interface MissingRevenueData {
  branchName: string;
  date: string; // The missing date
  managerName: string;
}

export function generateMissingRevenueReminder(data: MissingRevenueData): string {
  return `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>تذكير: لم يتم إدخال الإيراد اليومي</title>
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #f0ad4e 0%, #d89a3c 100%); padding: 40px 30px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: 700;">
                ⏰ تذكير: إيراد يومي مفقود
              </h1>
              <p style="margin: 10px 0 0 0; color: #fff8e6; font-size: 16px;">
                Symbol AI - نظام إدارة الفروع المتكامل
              </p>
            </td>
          </tr>
          
          <!-- Main Content -->
          <tr>
            <td style="padding: 40px 30px;">
              <p style="margin: 0 0 20px 0; font-size: 18px; color: #333; line-height: 1.6;">
                عزيزي <strong>${data.managerName}</strong>،
              </p>
              
              <p style="margin: 0 0 25px 0; font-size: 16px; color: #555; line-height: 1.8;">
                نود تذكيركم بأنه <strong style="color: #f0ad4e;">لم يتم إدخال الإيراد اليومي</strong> لفرع <strong>${data.branchName}</strong> بتاريخ <strong>${data.date}</strong>.
              </p>
              
              <!-- Alert Box -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #fff8e6; border-right: 4px solid #f0ad4e; border-radius: 8px; margin-bottom: 25px;">
                <tr>
                  <td style="padding: 25px;">
                    <p style="margin: 0 0 12px 0; font-size: 16px; color: #333; font-weight: 600;">
                      📋 الإجراء المطلوب:
                    </p>
                    <ul style="margin: 0; padding-right: 20px; font-size: 15px; color: #555; line-height: 1.8;">
                      <li>تسجيل الدخول إلى النظام</li>
                      <li>إدخال الإيراد اليومي للتاريخ المذكور</li>
                      <li>التأكد من صحة البيانات قبل الحفظ</li>
                      <li>مراجعة حالة التطابق (الموازنة = الشبكة)</li>
                    </ul>
                  </td>
                </tr>
              </table>
              
              <!-- Call to Action -->
              <table width="100%" cellpadding="0" cellspacing="0" style="margin: 30px 0;">
                <tr>
                  <td align="center">
                    <a href="https://branches.symbolai.net/revenues" 
                       style="display: inline-block; background-color: #f0ad4e; color: #ffffff; text-decoration: none; padding: 14px 40px; border-radius: 8px; font-size: 16px; font-weight: 600; box-shadow: 0 2px 8px rgba(240, 173, 78, 0.3);">
                      إدخال الإيراد الآن
                    </a>
                  </td>
                </tr>
              </table>
              
              <p style="margin: 25px 0 0 0; font-size: 14px; color: #888; line-height: 1.6;">
                <strong>ملاحظة:</strong> يُرجى إدخال الإيرادات اليومية في موعدها لضمان دقة التقارير المالية ومتابعة الأداء بشكل صحيح.
              </p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #2c2c2c; padding: 30px; text-align: center;">
              <p style="margin: 0 0 8px 0; font-size: 14px; color: #c19a5b; font-weight: 600;">
                Symbol AI © 2025
              </p>
              <p style="margin: 0 0 4px 0; font-size: 13px; color: #999;">
                جميع الحقوق محفوظة لصالح Symbol AI | مراقب النظام
              </p>
              <p style="margin: 0; font-size: 13px; color: #999;">
                All Rights Reserved to Symbol AI | System Monitor
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();
}
