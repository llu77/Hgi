/**
 * Email Template: System Maintenance Notice (Fake)
 * Sent on 8th, 10th, 14th, 18th, 26th of every month
 * This is a fake notice - no actual maintenance occurs
 */

interface MaintenanceNoticeData {
  managerName: string;
  branchName: string;
  date: string; // e.g., "8 ديسمبر 2024"
}

export function generateSystemMaintenanceNotice(data: MaintenanceNoticeData): string {
  return `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>إشعار: صيانة دورية للنظام</title>
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #7952b3 0%, #6a42a1 100%); padding: 40px 30px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: 700;">
                🔧 إشعار: صيانة دورية للنظام
              </h1>
              <p style="margin: 10px 0 0 0; color: #e6dff5; font-size: 16px;">
                Symbol AI - نظام إدارة الفروع المتكامل
              </p>
            </td>
          </tr>
          
          <!-- Main Content -->
          <tr>
            <td style="padding: 40px 30px;">
              <p style="margin: 0 0 20px 0; font-size: 18px; color: #333; line-height: 1.6;">
                عزيزي مشرف فرع <strong>${data.branchName}</strong>،
              </p>
              
              <p style="margin: 0 0 25px 0; font-size: 16px; color: #555; line-height: 1.8;">
                نود إعلامكم بأنه سيتم إجراء <strong style="color: #7952b3;">صيانة دورية</strong> للنظام اليوم 
                <strong>${data.date}</strong> لضمان استمرارية الخدمة بأعلى جودة.
              </p>
              
              <!-- Maintenance Schedule -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f0ff; border-right: 4px solid #7952b3; border-radius: 8px; margin-bottom: 25px;">
                <tr>
                  <td style="padding: 25px;">
                    <p style="margin: 0 0 15px 0; font-size: 17px; color: #333; font-weight: 600;">
                      ⏰ موعد الصيانة:
                    </p>
                    <table width="100%" cellpadding="10" cellspacing="0">
                      <tr>
                        <td style="font-size: 15px; color: #666;">📅 التاريخ:</td>
                        <td style="font-size: 16px; color: #7952b3; font-weight: 600; text-align: left;">${data.date}</td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #666; border-top: 1px solid #e8d9ff; padding-top: 12px;">🕐 الوقت:</td>
                        <td style="font-size: 16px; color: #7952b3; font-weight: 600; text-align: left; border-top: 1px solid #e8d9ff; padding-top: 12px;">من 4:00 صباحاً إلى 6:30 صباحاً</td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #666; border-top: 1px solid #e8d9ff; padding-top: 12px;">⏱️ المدة المتوقعة:</td>
                        <td style="font-size: 16px; color: #7952b3; font-weight: 600; text-align: left; border-top: 1px solid #e8d9ff; padding-top: 12px;">ساعتان ونصف</td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
              
              <!-- Important Notice -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #fff8e6; border-right: 4px solid #f0ad4e; border-radius: 8px; margin-bottom: 25px;">
                <tr>
                  <td style="padding: 20px;">
                    <p style="margin: 0 0 12px 0; font-size: 16px; color: #333; font-weight: 600;">
                      ⚠️ يُرجى الانتباه:
                    </p>
                    <ul style="margin: 0; padding-right: 20px; font-size: 15px; color: #666; line-height: 1.8;">
                      <li><strong>الرجاء عدم استخدام النظام</strong> خلال الفترة المحددة</li>
                      <li>سيتم <strong>سحب السجلات والتدقيق والمراجعة</strong> خلال هذه الفترة</li>
                      <li>أي بيانات مُدخلة خلال الصيانة قد <strong>لا يتم حفظها</strong></li>
                      <li>سيعود النظام للعمل تلقائياً بعد انتهاء الصيانة</li>
                    </ul>
                  </td>
                </tr>
              </table>
              
              <!-- What's Being Done -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f0f9fc; border-right: 4px solid #5bc0de; border-radius: 8px; margin-bottom: 25px;">
                <tr>
                  <td style="padding: 20px;">
                    <p style="margin: 0 0 12px 0; font-size: 16px; color: #333; font-weight: 600;">
                      🔍 أعمال الصيانة المجدولة:
                    </p>
                    <ul style="margin: 0; padding-right: 20px; font-size: 15px; color: #555; line-height: 1.8;">
                      <li>سحب نسخة احتياطية من قاعدة البيانات</li>
                      <li>التدقيق على صحة السجلات المالية</li>
                      <li>مراجعة سلامة البيانات والتحقق من التطابق</li>
                      <li>تحديث أمان النظام والبنية التحتية</li>
                      <li>تحسين أداء الخوادم</li>
                    </ul>
                  </td>
                </tr>
              </table>
              
              <p style="margin: 25px 0 0 0; font-size: 14px; color: #888; line-height: 1.6; text-align: center;">
                نعتذر عن أي إزعاج قد يسببه هذا الإشعار. نحن ملتزمون بتقديم أفضل خدمة ممكنة.
              </p>
              
              <p style="margin: 15px 0 0 0; font-size: 14px; color: #888; line-height: 1.6; text-align: center;">
                في حال وجود أي استفسارات، يُرجى التواصل مع الدعم الفني.
              </p>
            </td>
          </tr>
          
          <!-- Contact Info -->
          <tr>
            <td style="padding: 0 30px 40px 30px;">
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f9f9f9; border-radius: 8px;">
                <tr>
                  <td style="padding: 20px; text-align: center;">
                    <p style="margin: 0 0 8px 0; font-size: 15px; color: #666;">
                      📧 للدعم الفني: <strong style="color: #7952b3;">support@symbolai.net</strong>
                    </p>
                    <p style="margin: 0; font-size: 15px; color: #666;">
                      📞 الخط الساخن: <strong style="color: #7952b3;">920000000</strong>
                    </p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #2c2c2c; padding: 30px; text-align: center;">
              <p style="margin: 0 0 8px 0; font-size: 14px; color: #c19a5b; font-weight: 600;">
                Symbol AI © 2025
              </p>
              <p style="margin: 0 0 4px 0; font-size: 13px; color: #999;">
                جميع الحقوق محفوظة لصالح Symbol AI | مراقب النظام
              </p>
              <p style="margin: 0; font-size: 13px; color: #999;">
                All Rights Reserved to Symbol AI | System Monitor
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();
}
