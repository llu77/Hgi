/**
 * Email Template: High Expense Alert
 * Sent when an expense exceeding 1000 SAR is entered
 */

interface HighExpenseData {
  branchName: string;
  date: string;
  category: string;
  amount: number;
  description: string;
  employeeName?: string;
  receiptNumber?: string;
  managerName: string;
}

export function generateHighExpenseAlert(data: HighExpenseData): string {
  return `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>تنبيه: مصروف عالي</title>
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #d9534f 0%, #c9302c 100%); padding: 40px 30px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: 700;">
                💸 تنبيه: مصروف عالي
              </h1>
              <p style="margin: 10px 0 0 0; color: #ffe6e6; font-size: 16px;">
                Symbol AI - نظام إدارة الفروع المتكامل
              </p>
            </td>
          </tr>
          
          <!-- Main Content -->
          <tr>
            <td style="padding: 40px 30px;">
              <p style="margin: 0 0 20px 0; font-size: 18px; color: #333; line-height: 1.6;">
                عزيزي <strong>${data.managerName}</strong>،
              </p>
              
              <p style="margin: 0 0 25px 0; font-size: 16px; color: #555; line-height: 1.8;">
                تم تسجيل مصروف <strong style="color: #d9534f;">بمبلغ مرتفع</strong> في فرع <strong>${data.branchName}</strong>. 
                يُرجى مراجعة التفاصيل التالية:
              </p>
              
              <!-- Expense Details Card -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #fff5f5; border-right: 4px solid #d9534f; border-radius: 8px; margin-bottom: 25px;">
                <tr>
                  <td style="padding: 25px;">
                    <!-- Amount Highlight -->
                    <div style="text-align: center; background-color: #d9534f; color: #ffffff; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                      <p style="margin: 0 0 8px 0; font-size: 14px; opacity: 0.9;">المبلغ الإجمالي</p>
                      <p style="margin: 0; font-size: 36px; font-weight: 700;">${data.amount.toFixed(2)} ر.س</p>
                    </div>
                    
                    <table width="100%" cellpadding="8" cellspacing="0">
                      <tr>
                        <td style="font-size: 15px; color: #666; padding: 8px 0;">📅 <strong>التاريخ:</strong></td>
                        <td style="font-size: 15px; color: #333; text-align: left; padding: 8px 0;">${data.date}</td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #666; padding: 8px 0;">🏢 <strong>الفرع:</strong></td>
                        <td style="font-size: 15px; color: #333; text-align: left; padding: 8px 0;">${data.branchName}</td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #666; padding: 8px 0;">📂 <strong>الفئة:</strong></td>
                        <td style="font-size: 15px; color: #333; text-align: left; padding: 8px 0;">${data.category}</td>
                      </tr>
                      ${data.employeeName ? `
                      <tr>
                        <td style="font-size: 15px; color: #666; padding: 8px 0;">👤 <strong>الموظف:</strong></td>
                        <td style="font-size: 15px; color: #333; text-align: left; padding: 8px 0;">${data.employeeName}</td>
                      </tr>
                      ` : ''}
                      ${data.receiptNumber ? `
                      <tr>
                        <td style="font-size: 15px; color: #666; padding: 8px 0;">🧾 <strong>رقم الإيصال:</strong></td>
                        <td style="font-size: 15px; color: #333; text-align: left; padding: 8px 0;">${data.receiptNumber}</td>
                      </tr>
                      ` : ''}
                      <tr style="border-top: 1px solid #f0d4d4;">
                        <td colspan="2" style="padding: 12px 0 0 0;">
                          <p style="margin: 0; font-size: 14px; color: #666;"><strong>الوصف:</strong></p>
                          <p style="margin: 8px 0 0 0; font-size: 15px; color: #333; background-color: #fff; padding: 12px; border-radius: 6px;">
                            ${data.description || "لا يوجد وصف"}
                          </p>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
              
              <!-- Warning Notice -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #fff8e6; border-right: 4px solid #f0ad4e; border-radius: 8px; margin-bottom: 25px;">
                <tr>
                  <td style="padding: 20px;">
                    <p style="margin: 0; font-size: 15px; color: #666; line-height: 1.7;">
                      <strong style="color: #f0ad4e;">⚠️ إجراء مطلوب:</strong> 
                      يُرجى التحقق من صحة البيانات المدخلة والتأكد من وجود المستندات الداعمة (فاتورة، إيصال، موافقة). 
                      في حال وجود أي خطأ، يُرجى تصحيحه فوراً.
                    </p>
                  </td>
                </tr>
              </table>
              
              <!-- Call to Action -->
              <table width="100%" cellpadding="0" cellspacing="0" style="margin: 30px 0;">
                <tr>
                  <td align="center">
                    <a href="https://branches.symbolai.net/expenses" 
                       style="display: inline-block; background-color: #d9534f; color: #ffffff; text-decoration: none; padding: 14px 40px; border-radius: 8px; font-size: 16px; font-weight: 600; box-shadow: 0 2px 8px rgba(217, 83, 79, 0.3);">
                      مراجعة المصروفات
                    </a>
                  </td>
                </tr>
              </table>
              
              <p style="margin: 25px 0 0 0; font-size: 14px; color: #888; line-height: 1.6; text-align: center;">
                هذا التنبيه تلقائي لأي مصروف يتجاوز 1,000 ريال سعودي.
              </p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #2c2c2c; padding: 30px; text-align: center;">
              <p style="margin: 0 0 8px 0; font-size: 14px; color: #c19a5b; font-weight: 600;">
                Symbol AI © 2025
              </p>
              <p style="margin: 0 0 4px 0; font-size: 13px; color: #999;">
                جميع الحقوق محفوظة لصالح Symbol AI | مراقب النظام
              </p>
              <p style="margin: 0; font-size: 13px; color: #999;">
                All Rights Reserved to Symbol AI | System Monitor
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();
}
