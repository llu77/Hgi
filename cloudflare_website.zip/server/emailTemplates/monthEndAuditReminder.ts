/**
 * Email Template: Month-End Audit Reminder
 * Sent on the 28th of every month to remind managers to prepare for month-end closing
 */

interface MonthEndAuditData {
  managerName: string;
  currentMonth: string; // e.g., "ديسمبر 2024"
  branchName?: string; // Optional: specific branch or "جميع الفروع"
}

export function generateMonthEndAuditReminder(data: MonthEndAuditData): string {
  return `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>تذكير: التدقيق قبل نهاية الشهر</title>
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #5bc0de 0%, #46a8c4 100%); padding: 40px 30px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: 700;">
                📅 تذكير: التدقيق قبل نهاية الشهر
              </h1>
              <p style="margin: 10px 0 0 0; color: #e6f7fb; font-size: 16px;">
                Symbol AI - نظام إدارة الفروع المتكامل
              </p>
            </td>
          </tr>
          
          <!-- Main Content -->
          <tr>
            <td style="padding: 40px 30px;">
              <p style="margin: 0 0 20px 0; font-size: 18px; color: #333; line-height: 1.6;">
                عزيزي <strong>${data.managerName}</strong>،
              </p>
              
              <p style="margin: 0 0 25px 0; font-size: 16px; color: #555; line-height: 1.8;">
                نود تذكيركم بأننا على وشك إنهاء شهر <strong style="color: #5bc0de;">${data.currentMonth}</strong>. 
                يُرجى البدء في عملية <strong>التدقيق والمراجعة النهائية</strong> للسجلات المالية وإعداد مسيرات الرواتب.
              </p>
              
              <!-- Checklist -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f0f9fc; border-right: 4px solid #5bc0de; border-radius: 8px; margin-bottom: 25px;">
                <tr>
                  <td style="padding: 25px;">
                    <p style="margin: 0 0 15px 0; font-size: 16px; color: #333; font-weight: 600;">
                      ✅ قائمة المراجعة قبل نهاية الشهر:
                    </p>
                    <table width="100%" cellpadding="8" cellspacing="0">
                      <tr>
                        <td style="font-size: 15px; color: #555; padding: 6px 0;">
                          ☑️ مراجعة جميع الإيرادات اليومية المسجلة
                        </td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #555; padding: 6px 0;">
                          ☑️ التحقق من حالة التطابق لجميع الإيرادات
                        </td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #555; padding: 6px 0;">
                          ☑️ مراجعة جميع المصروفات المسجلة
                        </td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #555; padding: 6px 0;">
                          ☑️ التأكد من صحة تصنيف المصروفات
                        </td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #555; padding: 6px 0;">
                          ☑️ مراجعة سجلات الموظفين وأيام العمل
                        </td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #555; padding: 6px 0;">
                          ☑️ إعداد مسيرات الرواتب للشهر الحالي
                        </td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #555; padding: 6px 0;">
                          ☑️ تصدير التقارير المالية (PDF/Excel)
                        </td>
                      </tr>
                      <tr>
                        <td style="font-size: 15px; color: #555; padding: 6px 0;">
                          ☑️ إرسال التقارير للإدارة العليا
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
              
              <!-- Important Notice -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #fff8e6; border-right: 4px solid #f0ad4e; border-radius: 8px; margin-bottom: 25px;">
                <tr>
                  <td style="padding: 20px;">
                    <p style="margin: 0; font-size: 15px; color: #666; line-height: 1.7;">
                      <strong style="color: #f0ad4e;">⚠️ تنبيه مهم:</strong> 
                      يُرجى إتمام جميع عمليات التدقيق والمراجعة قبل نهاية الشهر لضمان دقة التقارير المالية وإصدار مسيرات الرواتب في الوقت المحدد.
                    </p>
                  </td>
                </tr>
              </table>
              
              <!-- Call to Action -->
              <table width="100%" cellpadding="0" cellspacing="0" style="margin: 30px 0;">
                <tr>
                  <td align="center">
                    <a href="https://branches.symbolai.net/dashboard" 
                       style="display: inline-block; background-color: #5bc0de; color: #ffffff; text-decoration: none; padding: 14px 40px; border-radius: 8px; font-size: 16px; font-weight: 600; box-shadow: 0 2px 8px rgba(91, 192, 222, 0.3); margin-left: 10px;">
                      الانتقال إلى لوحة التحكم
                    </a>
                    <a href="https://branches.symbolai.net/revenues" 
                       style="display: inline-block; background-color: #c19a5b; color: #ffffff; text-decoration: none; padding: 14px 40px; border-radius: 8px; font-size: 16px; font-weight: 600; box-shadow: 0 2px 8px rgba(193, 154, 91, 0.3);">
                      مراجعة الإيرادات
                    </a>
                  </td>
                </tr>
              </table>
              
              <p style="margin: 25px 0 0 0; font-size: 14px; color: #888; line-height: 1.6; text-align: center;">
                في حال وجود أي استفسارات، يُرجى التواصل مع الإدارة المالية.
              </p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #2c2c2c; padding: 30px; text-align: center;">
              <p style="margin: 0 0 8px 0; font-size: 14px; color: #c19a5b; font-weight: 600;">
                Symbol AI © 2025
              </p>
              <p style="margin: 0 0 4px 0; font-size: 13px; color: #999;">
                جميع الحقوق محفوظة لصالح Symbol AI | مراقب النظام
              </p>
              <p style="margin: 0; font-size: 13px; color: #999;">
                All Rights Reserved to Symbol AI | System Monitor
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();
}
