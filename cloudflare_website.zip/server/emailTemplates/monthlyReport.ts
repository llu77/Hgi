/**
 * Email Template: Monthly Report
 * Sent on the 1st of every month with comprehensive financial summary of previous month
 */

interface MonthlyReportData {
  month: string; // e.g., "نوفمبر 2024"
  totalRevenue: number;
  totalExpenses: number;
  netProfit: number;
  totalCash: number;
  totalNetwork: number;
  matchedRevenuesCount: number;
  unmatchedRevenuesCount: number;
  topExpenseCategory: string;
  topExpenseAmount: number;
  branchesCount: number;
  employeesCount: number;
}

export function generateMonthlyReport(data: MonthlyReportData): string {
  const profitPercentage = data.totalRevenue > 0 
    ? ((data.netProfit / data.totalRevenue) * 100).toFixed(1) 
    : "0.0";
  const matchPercentage = (data.matchedRevenuesCount + data.unmatchedRevenuesCount) > 0
    ? ((data.matchedRevenuesCount / (data.matchedRevenuesCount + data.unmatchedRevenuesCount)) * 100).toFixed(1)
    : "0.0";

  return `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>التقرير المالي الشهري - ${data.month}</title>
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="700" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #2c7a3f 0%, #1f5a2e 100%); padding: 40px 30px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 32px; font-weight: 700;">
                📊 التقرير المالي الشهري
              </h1>
              <p style="margin: 15px 0 0 0; color: #d4f0db; font-size: 20px; font-weight: 600;">
                ${data.month}
              </p>
              <p style="margin: 8px 0 0 0; color: #d4f0db; font-size: 14px;">
                Symbol AI - نظام إدارة الفروع المتكامل
              </p>
            </td>
          </tr>
          
          <!-- Executive Summary -->
          <tr>
            <td style="padding: 40px 30px 30px 30px;">
              <h2 style="margin: 0 0 20px 0; font-size: 22px; color: #2c7a3f; border-bottom: 3px solid #2c7a3f; padding-bottom: 10px;">
                📈 الملخص التنفيذي
              </h2>
              
              <!-- KPI Cards Grid -->
              <table width="100%" cellpadding="0" cellspacing="15">
                <tr>
                  <!-- Net Profit -->
                  <td width="50%" style="background: linear-gradient(135deg, #2c7a3f 0%, #1f5a2e 100%); border-radius: 10px; padding: 25px; text-align: center;">
                    <p style="margin: 0 0 8px 0; font-size: 14px; color: #d4f0db;">الربح الصافي</p>
                    <p style="margin: 0; font-size: 32px; font-weight: 700; color: #ffffff;">${data.netProfit.toFixed(2)}</p>
                    <p style="margin: 5px 0 0 0; font-size: 16px; color: #d4f0db;">ريال سعودي</p>
                    <p style="margin: 10px 0 0 0; font-size: 13px; color: #b8e6c4;">هامش الربح: ${profitPercentage}%</p>
                  </td>
                  
                  <!-- Total Revenue -->
                  <td width="50%" style="background-color: #f0f9fc; border: 2px solid #5bc0de; border-radius: 10px; padding: 25px; text-align: center;">
                    <p style="margin: 0 0 8px 0; font-size: 14px; color: #46a8c4;">إجمالي الإيرادات</p>
                    <p style="margin: 0; font-size: 32px; font-weight: 700; color: #5bc0de;">${data.totalRevenue.toFixed(2)}</p>
                    <p style="margin: 5px 0 0 0; font-size: 16px; color: #46a8c4;">ريال سعودي</p>
                  </td>
                </tr>
                <tr>
                  <!-- Total Expenses -->
                  <td width="50%" style="background-color: #fff5f5; border: 2px solid #d9534f; border-radius: 10px; padding: 25px; text-align: center;">
                    <p style="margin: 0 0 8px 0; font-size: 14px; color: #c9302c;">إجمالي المصروفات</p>
                    <p style="margin: 0; font-size: 32px; font-weight: 700; color: #d9534f;">${data.totalExpenses.toFixed(2)}</p>
                    <p style="margin: 5px 0 0 0; font-size: 16px; color: #c9302c;">ريال سعودي</p>
                  </td>
                  
                  <!-- Match Rate -->
                  <td width="50%" style="background-color: #fff8e6; border: 2px solid #f0ad4e; border-radius: 10px; padding: 25px; text-align: center;">
                    <p style="margin: 0 0 8px 0; font-size: 14px; color: #d89a3c;">نسبة التطابق</p>
                    <p style="margin: 0; font-size: 32px; font-weight: 700; color: #f0ad4e;">${matchPercentage}%</p>
                    <p style="margin: 5px 0 0 0; font-size: 13px; color: #d89a3c;">${data.matchedRevenuesCount} متطابق / ${data.unmatchedRevenuesCount} غير متطابق</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Revenue Breakdown -->
          <tr>
            <td style="padding: 0 30px 30px 30px;">
              <h2 style="margin: 0 0 20px 0; font-size: 22px; color: #2c7a3f; border-bottom: 3px solid #2c7a3f; padding-bottom: 10px;">
                💰 تفصيل الإيرادات
              </h2>
              
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f9f9f9; border-radius: 8px; overflow: hidden;">
                <tr style="background-color: #e8e8e8;">
                  <th style="padding: 15px; text-align: right; font-size: 15px; color: #555; border-bottom: 2px solid #ddd;">البند</th>
                  <th style="padding: 15px; text-align: left; font-size: 15px; color: #555; border-bottom: 2px solid #ddd;">المبلغ (ر.س)</th>
                </tr>
                <tr>
                  <td style="padding: 12px 15px; font-size: 15px; color: #333; border-bottom: 1px solid #e8e8e8;">💵 الكاش</td>
                  <td style="padding: 12px 15px; font-size: 16px; color: #2c7a3f; font-weight: 600; text-align: left; border-bottom: 1px solid #e8e8e8;">${data.totalCash.toFixed(2)}</td>
                </tr>
                <tr>
                  <td style="padding: 12px 15px; font-size: 15px; color: #333; border-bottom: 1px solid #e8e8e8;">💳 الشبكة</td>
                  <td style="padding: 12px 15px; font-size: 16px; color: #2c7a3f; font-weight: 600; text-align: left; border-bottom: 1px solid #e8e8e8;">${data.totalNetwork.toFixed(2)}</td>
                </tr>
                <tr style="background-color: #e8f5e9;">
                  <td style="padding: 15px; font-size: 16px; color: #1f5a2e; font-weight: 700;">📊 الإجمالي</td>
                  <td style="padding: 15px; font-size: 18px; color: #1f5a2e; font-weight: 700; text-align: left;">${data.totalRevenue.toFixed(2)}</td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Expense Insights -->
          <tr>
            <td style="padding: 0 30px 30px 30px;">
              <h2 style="margin: 0 0 20px 0; font-size: 22px; color: #2c7a3f; border-bottom: 3px solid #2c7a3f; padding-bottom: 10px;">
                📉 تحليل المصروفات
              </h2>
              
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #fff5f5; border-right: 4px solid #d9534f; border-radius: 8px;">
                <tr>
                  <td style="padding: 20px;">
                    <p style="margin: 0 0 10px 0; font-size: 15px; color: #666;">
                      <strong>أكبر فئة مصروفات:</strong>
                    </p>
                    <p style="margin: 0; font-size: 18px; color: #d9534f; font-weight: 600;">
                      ${data.topExpenseCategory} - ${data.topExpenseAmount.toFixed(2)} ر.س
                    </p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Statistics -->
          <tr>
            <td style="padding: 0 30px 40px 30px;">
              <h2 style="margin: 0 0 20px 0; font-size: 22px; color: #2c7a3f; border-bottom: 3px solid #2c7a3f; padding-bottom: 10px;">
                📋 إحصائيات عامة
              </h2>
              
              <table width="100%" cellpadding="12" cellspacing="0" style="background-color: #f9f9f9; border-radius: 8px;">
                <tr>
                  <td style="font-size: 15px; color: #666; padding: 10px 15px;">🏢 عدد الفروع</td>
                  <td style="font-size: 16px; color: #333; font-weight: 600; text-align: left; padding: 10px 15px;">${data.branchesCount}</td>
                </tr>
                <tr>
                  <td style="font-size: 15px; color: #666; padding: 10px 15px; border-top: 1px solid #e8e8e8;">👥 عدد الموظفين</td>
                  <td style="font-size: 16px; color: #333; font-weight: 600; text-align: left; padding: 10px 15px; border-top: 1px solid #e8e8e8;">${data.employeesCount}</td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Call to Action -->
          <tr>
            <td style="padding: 0 30px 40px 30px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="https://branches.symbolai.net/dashboard" 
                       style="display: inline-block; background-color: #2c7a3f; color: #ffffff; text-decoration: none; padding: 16px 50px; border-radius: 8px; font-size: 17px; font-weight: 600; box-shadow: 0 3px 10px rgba(44, 122, 63, 0.3);">
                      عرض التقرير التفصيلي
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #2c2c2c; padding: 30px; text-align: center;">
              <p style="margin: 0 0 8px 0; font-size: 14px; color: #c19a5b; font-weight: 600;">
                Symbol AI © 2025
              </p>
              <p style="margin: 0 0 4px 0; font-size: 13px; color: #999;">
                جميع الحقوق محفوظة لصالح Symbol AI | مراقب النظام
              </p>
              <p style="margin: 0; font-size: 13px; color: #999;">
                All Rights Reserved to Symbol AI | System Monitor
              </p>
              <p style="margin: 15px 0 0 0; font-size: 12px; color: #777;">
                تم إنشاء هذا التقرير تلقائياً في 1 ${data.month.split(' ')[1]}
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();
}
